document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-postr-digital-memory]").forEach(wrapper => {
    const checkbox = wrapper.querySelector("[data-postr-memory-checkbox]");
    const status = wrapper.querySelector("[data-postr-memory-status]");

    if (!checkbox) return;

    let timer = null;

    checkbox.addEventListener("change", async () => {
      const enabledValue = wrapper.dataset.enabledValue || "Yes";
      const value = checkbox.checked ? enabledValue : "";

      status.textContent = "Saving…";
      status.className = "postr-digital-memory__status";

      try {
        const response = await fetch(
          (window.Shopify?.routes?.root || "/") + "cart/update.js",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Accept": "application/json"
            },
            body: JSON.stringify({
              attributes: {
                "Digital Memory QR": value
              }
            })
          }
        );

        if (!response.ok) {
          throw new Error("Could not save Digital Memory preference.");
        }

        status.textContent = checkbox.checked
          ? "Digital Memory QR added to your order."
          : "Digital Memory QR removed.";
        status.className = "postr-digital-memory__status is-saved";

        clearTimeout(timer);
        timer = setTimeout(() => {
          status.textContent = "";
        }, 2500);
      } catch (error) {
        status.textContent = "Could not save. Please try again.";
        status.className = "postr-digital-memory__status is-error";

        // Revert the checkbox so UI matches stored state.
        checkbox.checked = !checkbox.checked;
      }
    });
  });
});
