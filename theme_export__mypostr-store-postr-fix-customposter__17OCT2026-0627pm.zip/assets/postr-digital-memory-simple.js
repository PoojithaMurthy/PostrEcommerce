document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-postr-memory-choice]").forEach(wrapper => {
    const buttons = [...wrapper.querySelectorAll("[data-postr-memory-value]")];
    const status = wrapper.querySelector("[data-postr-memory-status]");

    const setVisualState = value => {
      buttons.forEach(button => {
        const active = button.dataset.postrMemoryValue === value;
        button.classList.toggle("is-active", active);
        button.setAttribute("aria-pressed", active ? "true" : "false");
      });
      wrapper.dataset.current = value;
    };

    buttons.forEach(button => {
      button.addEventListener("click", async () => {
        const nextValue = button.dataset.postrMemoryValue || "";
        const previousValue = wrapper.dataset.current || "";

        if (nextValue === previousValue) return;

        buttons.forEach(item => item.disabled = true);
        if (status) status.textContent = "Saving Digital Memory preference.";

        try {
          const response = await fetch(
            (window.Shopify?.routes?.root || "/") + "cart/update.js",
            {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                "Accept": "application/json"
              },
              body: JSON.stringify({
                attributes: {
                  "Digital Memory QR": nextValue
                }
              })
            }
          );

          const data = await response.json();

          if (!response.ok) {
            throw new Error(data?.description || "Could not save option.");
          }

          setVisualState(nextValue);

          if (status) {
            status.textContent = nextValue === "Yes"
              ? "Digital Memory QR selected."
              : "Digital Memory QR not selected.";
          }
        } catch (error) {
          setVisualState(previousValue);
          if (status) status.textContent = "Could not save Digital Memory preference.";
          console.error("POSTR Digital Memory:", error);
        } finally {
          buttons.forEach(item => item.disabled = false);
        }
      });
    });
  });
});
