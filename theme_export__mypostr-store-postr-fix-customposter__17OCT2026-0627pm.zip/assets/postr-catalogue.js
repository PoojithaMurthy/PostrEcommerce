/*
  Postr catalogue layer — filters, search and the poster detail popup.

  Reads the catalogue emitted by snippets/postr-catalogue.liquid and matches it
  onto the poster cards by display name. Everything here is additive: a card
  with no catalogue entry still renders and still adds to cart, it just has no
  description and sits outside every collection filter.

  The detail popup deliberately does NOT reimplement add-to-cart. It proxies to
  the card's own size buttons, quantity input and add button, so there is one
  cart code path (in postr-4tab.js) rather than two that can drift apart.
*/
(function () {
  "use strict";

  var dataEl = document.getElementById("postr-catalogue");
  // The 47 designs live across two sections (Shopify caps blocks per section),
  // so the catalogue treats every marked grid as one combined set.
  var grids = [].slice.call(document.querySelectorAll("[data-postr-catalogue-grid]"));
  if (!dataEl || !grids.length) return;

  var catalogue;
  try {
    catalogue = JSON.parse(dataEl.textContent);
  } catch (e) {
    // Malformed catalogue must not take the shop down — cards stay usable.
    console.error("Postr catalogue: could not parse catalogue JSON.", e);
    return;
  }

  var COLLECTIONS = catalogue.collections || [];
  var DESIGNS = catalogue.designs || [];

  var norm = function (s) {
    return String(s || "")
      .toLowerCase()
      .replace(/#/g, "")
      .replace(/[‘’]/g, "'")
      .replace(/[–—]/g, "-")
      .replace(/\s+/g, " ")
      .trim();
  };

  var byName = {};
  DESIGNS.forEach(function (d) { byName[norm(d.n)] = d; });

  var collectionName = {};
  COLLECTIONS.forEach(function (c) { collectionName[c.id] = c.name; });

  /* ---------- 1. enrich cards ---------- */

  var cards = grids.reduce(function (acc, g) {
    return acc.concat([].slice.call(g.querySelectorAll(".postr-card")));
  }, []);
  var matched = 0;

  cards.forEach(function (card) {
    var addBtn = card.querySelector("[data-ready-add]");
    var heading = card.querySelector("h3");
    var name = (addBtn && addBtn.dataset.posterName) || (heading && heading.textContent) || "";
    var entry = byName[norm(name)];

    card.dataset.postrName = name.trim();

    if (!entry) {
      card.dataset.postrCollection = "";
      card.dataset.postrSearch = norm(name);
      return;
    }

    matched++;

    // "Poster Type" reaches the cart, the order and the packing slip. The old
    // values ("Movies & Series", "Sports & Others") were tab names that no
    // longer exist — replace them with the design's real collection.
    if (addBtn) {
      var full = (COLLECTIONS.filter(function (c) { return c.id === entry.c; })[0] || {}).full;
      if (full) addBtn.dataset.posterType = full;
      // The catalogue code is the unambiguous print instruction: two designs
      // can read similarly, but PSTR-TVC-04 maps to exactly one page of the
      // printed catalogue.
      addBtn.dataset.posterCode = entry.sku;
    }

    card.dataset.postrSku = entry.sku;
    card.dataset.postrCollection = entry.c;
    card.dataset.postrDesc = entry.d;
    card.dataset.postrWhy = entry.w;

    var tags = entry.t || [];
    card.dataset.postrTags = tags.join(",");

    // Tags join the search text so "breaking" would match "BreakingBad" and
    // "scifi" would match "SciFi" — substring, so no # is ever required.
    card.dataset.postrSearch = norm(
      [entry.n, entry.d, entry.w, entry.sku, collectionName[entry.c]]
        .concat(tags)
        .join(" ")
    );

    // A one-line description on the card itself, above the size selector.
    var body = card.querySelector(".postr-card__body");
    var sizeWrap = body && body.querySelector(".postr-ready-size-wrap");
    if (body && !body.querySelector(".postr-card__desc")) {
      var p = document.createElement("p");
      p.className = "postr-card__desc";
      p.textContent = entry.d;
      if (sizeWrap) body.insertBefore(p, sizeWrap);
      else body.appendChild(p);
    }
    if (body && tags.length && !body.querySelector(".postr-card__tags")) {
      var tagWrap = document.createElement("p");
      tagWrap.className = "postr-card__tags";
      tagWrap.textContent = tags.map(function (t) { return "#" + t; }).join(" ");
      if (sizeWrap) body.insertBefore(tagWrap, sizeWrap);
      else body.appendChild(tagWrap);
    }
  });

  /* ---------- 2. filter + search UI ---------- */

  var controls = document.querySelector("[data-postr-catalogue-controls]");
  var state = { collection: "all", query: "" };

  function countFor(id) {
    return cards.filter(function (c) {
      return id === "all" ? true : c.dataset.postrCollection === id;
    }).length;
  }

  if (controls) {
    var search = document.createElement("div");
    search.className = "postr-search";
    search.innerHTML =
      '<label class="visually-hidden" for="postr-search-input">Search posters</label>' +
      '<span class="postr-search__icon" aria-hidden="true">' +
        '<svg viewBox="0 0 20 20" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.7">' +
        '<circle cx="9" cy="9" r="6"/><path d="M13.5 13.5 17 17" stroke-linecap="round"/></svg>' +
      '</span>' +
      '<input id="postr-search-input" type="search" placeholder="Search posters, movies, actors or genres" autocomplete="off" data-postr-search>' +
      '<button type="button" class="postr-search__clear" data-postr-search-clear hidden aria-label="Clear search">&times;</button>';

    var chips = document.createElement("div");
    chips.className = "postr-chips";
    chips.setAttribute("role", "group");
    chips.setAttribute("aria-label", "Filter posters by collection");

    var chipDefs = [{ id: "all", name: "All" }].concat(
      COLLECTIONS.map(function (c) { return { id: c.id, name: c.name }; })
    );

    chipDefs.forEach(function (def) {
      var n = countFor(def.id);
      if (def.id !== "all" && n === 0) return; // never show an empty filter
      var b = document.createElement("button");
      b.type = "button";
      b.className = "postr-chip" + (def.id === "all" ? " is-on" : "");
      b.dataset.postrChip = def.id;
      b.setAttribute("aria-pressed", def.id === "all" ? "true" : "false");
      b.innerHTML = '<span>' + def.name + '</span><small>' + n + '</small>';
      chips.appendChild(b);
    });

    controls.appendChild(search);
    controls.appendChild(chips);

    var resultLine = document.createElement("p");
    resultLine.className = "postr-result-line";
    resultLine.setAttribute("aria-live", "polite");
    controls.appendChild(resultLine);

    var input = search.querySelector("[data-postr-search]");
    var clearBtn = search.querySelector("[data-postr-search-clear]");

    var apply = function () {
      var q = norm(state.query);
      var shown = 0;

      var matched = [];
      cards.forEach(function (card) {
        var okCollection = state.collection === "all" || card.dataset.postrCollection === state.collection;
        var okQuery = !q || (card.dataset.postrSearch || "").indexOf(q) !== -1;
        var show = okCollection && okQuery;
        card.hidden = !show;
        if (show) { shown++; if (q) matched.push(card); }
      });

      // Rank the matches: exact title, then title prefix, then a tag hit, then
      // anything else. Reordering only happens while a query is active, so the
      // authored order is untouched when the box is empty.
      if (q && matched.length > 1) {
        matched
          .map(function (card) {
            var name = norm(card.dataset.postrName);
            var tags = norm(card.dataset.postrTags || "").split(",");
            var rank = 4;
            if (name === q) rank = 0;
            else if (name.indexOf(q) === 0) rank = 1;
            else if (name.indexOf(q) !== -1) rank = 2;
            else if (tags.some(function (t) { return t.indexOf(q) !== -1; })) rank = 3;
            return { card: card, rank: rank };
          })
          .sort(function (a, b) { return a.rank - b.rank; })
          .forEach(function (item) { item.card.parentNode.appendChild(item.card); });
      }

      chips.querySelectorAll("[data-postr-chip]").forEach(function (b) {
        var on = b.dataset.postrChip === state.collection;
        b.classList.toggle("is-on", on);
        b.setAttribute("aria-pressed", on ? "true" : "false");
      });

      clearBtn.hidden = !state.query;

      if (q && shown === 0) {
        resultLine.textContent = 'No posters found for "' + state.query.trim() + '"';
        resultLine.hidden = false;
      } else if (q) {
        resultLine.textContent = shown + (shown === 1 ? " poster" : " posters") + " found";
        resultLine.hidden = false;
      } else if (state.collection !== "all") {
        resultLine.textContent = shown + (shown === 1 ? " poster" : " posters") + " in " + collectionName[state.collection];
        resultLine.hidden = false;
      } else {
        resultLine.hidden = true;
      }
    };

    chips.addEventListener("click", function (e) {
      var b = e.target.closest("[data-postr-chip]");
      if (!b) return;
      state.collection = b.dataset.postrChip;
      apply();
    });

    var debounce;
    input.addEventListener("input", function () {
      clearTimeout(debounce);
      debounce = setTimeout(function () {
        state.query = input.value;
        apply();
      }, 120);
    });

    clearBtn.addEventListener("click", function () {
      input.value = "";
      state.query = "";
      apply();
      input.focus();
    });

    apply();
  }

  /* ---------- 3. detail popup ---------- */

  var modal = null;
  var lastFocus = null;

  function buildModal() {
    var el = document.createElement("div");
    el.className = "postr-detail";
    el.setAttribute("data-postr-detail", "");
    el.hidden = true;
    el.innerHTML =
      '<div class="postr-detail__dialog" role="dialog" aria-modal="true" aria-labelledby="postr-detail-title">' +
        '<button type="button" class="postr-detail__close" data-postr-detail-close aria-label="Close">&times;</button>' +
        '<div class="postr-detail__media"><img data-postr-detail-img alt=""></div>' +
        '<div class="postr-detail__body">' +
          '<p class="postr-detail__eyebrow" data-postr-detail-eyebrow></p>' +
          '<h3 id="postr-detail-title" data-postr-detail-title></h3>' +
          '<p class="postr-detail__desc" data-postr-detail-desc></p>' +
          '<p class="postr-detail__why" data-postr-detail-why></p>' +
          '<p class="postr-detail__tags" data-postr-detail-tags></p>' +
          '<div class="postr-detail__sizes" data-postr-detail-sizes role="group" aria-label="Poster size"></div>' +
          '<p class="postr-detail__total" data-postr-detail-total></p>' +
          '<div class="postr-detail__buy">' +
            '<div class="postr-qty postr-detail__qty">' +
              '<button type="button" data-postr-detail-minus aria-label="Decrease quantity">&minus;</button>' +
              '<input type="number" min="1" value="1" data-postr-detail-qty aria-label="Quantity">' +
              '<button type="button" data-postr-detail-plus aria-label="Increase quantity">+</button>' +
            '</div>' +
            '<button type="button" class="postr-detail__add" data-postr-detail-add></button>' +
          '</div>' +
          '<p class="postr-detail__note">Ships in a rigid tube. Dispatched within 48 hours.</p>' +
        '</div>' +
      '</div>';
    document.body.appendChild(el);

    el.addEventListener("click", function (e) {
      if (e.target === el || e.target.closest("[data-postr-detail-close]")) closeModal();
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && modal && !modal.hidden) closeModal();
    });
    return el;
  }

  function closeModal() {
    if (!modal) return;
    modal.hidden = true;
    document.documentElement.classList.remove("postr-detail-open");
    if (lastFocus && typeof lastFocus.focus === "function") lastFocus.focus();
  }

  function openModal(card) {
    if (!modal) modal = buildModal();
    lastFocus = document.activeElement;

    var addBtn = card.querySelector("[data-ready-add]");
    var img = card.querySelector(".postr-card__image img");
    var trigger = card.querySelector("[data-postr-lightbox-src]");
    var name = card.dataset.postrName || "";

    var mImg = modal.querySelector("[data-postr-detail-img]");
    mImg.src = (trigger && trigger.getAttribute("data-postr-lightbox-src")) || (img && img.src) || "";
    mImg.alt = name;

    var coll = collectionName[card.dataset.postrCollection];
    var sku = card.dataset.postrSku;
    modal.querySelector("[data-postr-detail-eyebrow]").textContent =
      [coll, sku].filter(Boolean).join(" · ");

    modal.querySelector("[data-postr-detail-title]").textContent = name;

    var descEl = modal.querySelector("[data-postr-detail-desc]");
    descEl.textContent = card.dataset.postrDesc || "";
    descEl.hidden = !card.dataset.postrDesc;

    var whyEl = modal.querySelector("[data-postr-detail-why]");
    whyEl.textContent = card.dataset.postrWhy || "";
    whyEl.hidden = !card.dataset.postrWhy;

    var tagEl = modal.querySelector("[data-postr-detail-tags]");
    var cardTags = (card.dataset.postrTags || "").split(",").filter(Boolean);
    tagEl.textContent = cardTags.map(function (t) { return "#" + t; }).join(" ");
    tagEl.hidden = cardTags.length === 0;

    // Size buttons proxy to the card's real ones.
    var sizesWrap = modal.querySelector("[data-postr-detail-sizes]");
    sizesWrap.innerHTML = "";
    var cardSizes = [].slice.call(card.querySelectorAll("[data-ready-size]"));

    cardSizes.forEach(function (src) {
      var b = document.createElement("button");
      b.type = "button";
      b.className = "postr-detail__size" + (src.classList.contains("is-active") ? " is-active" : "");
      if (src.disabled) b.disabled = true;
      var label = src.querySelector("span");
      var price = src.querySelector("small");
      b.innerHTML =
        "<span>" + (label ? label.textContent : "") + "</span>" +
        "<small>" + (price ? price.textContent : "") + "</small>";
      b.addEventListener("click", function () {
        src.click(); // single source of truth for price/variant sync
        sizesWrap.querySelectorAll(".postr-detail__size").forEach(function (x) {
          x.classList.remove("is-active");
        });
        b.classList.add("is-active");
      });
      sizesWrap.appendChild(b);
    });
    sizesWrap.hidden = cardSizes.length === 0;

    // Quantity mirrors the card's input both ways.
    var cardQty = card.querySelector("[data-ready-qty]");
    var mQty = modal.querySelector("[data-postr-detail-qty]");
    mQty.value = cardQty ? cardQty.value : 1;

    var syncQty = function (v) {
      var n = Math.max(1, Number(v) || 1);
      mQty.value = n;
      if (cardQty) cardQty.value = n;
      // Let the card recalculate its line total, then mirror it in the popup.
      document.dispatchEvent(new CustomEvent("postr:qty-changed", { detail: { card: card } }));
      var cardPrice = card.querySelector("[data-ready-price]");
      var mTotal = modal.querySelector("[data-postr-detail-total]");
      if (cardPrice && mTotal) mTotal.textContent = cardPrice.textContent.trim();
    };
    modal.querySelector("[data-postr-detail-minus]").onclick = function () { syncQty(Number(mQty.value) - 1); };
    modal.querySelector("[data-postr-detail-plus]").onclick = function () { syncQty(Number(mQty.value) + 1); };
    mQty.onchange = function () { syncQty(mQty.value); };
    syncQty(mQty.value);

    var mAdd = modal.querySelector("[data-postr-detail-add]");
    mAdd.textContent = "Add to Cart";
    mAdd.disabled = false;
    mAdd.onclick = function () {
      if (!addBtn) return;
      syncQty(mQty.value);
      mAdd.disabled = true;
      mAdd.textContent = "Adding…";
      addBtn.click();
      // Mirror the card button's own result rather than guessing at it.
      var watch = setInterval(function () {
        var t = (addBtn.textContent || "").trim();
        if (t.indexOf("Added") === 0) {
          mAdd.textContent = "Added ✓";
          clearInterval(watch);
          setTimeout(function () {
            mAdd.disabled = false;
            mAdd.textContent = "Add to Cart";
          }, 1200);
        } else if (t === "Add to Cart") {
          mAdd.disabled = false;
          mAdd.textContent = "Add to Cart";
          clearInterval(watch);
        }
      }, 150);
      setTimeout(function () { clearInterval(watch); }, 8000);
    };

    modal.hidden = false;
    document.documentElement.classList.add("postr-detail-open");
    modal.querySelector("[data-postr-detail-close]").focus();
  }

  // Take over the image trigger: it opened a bare lightbox, it now opens detail.
  // Capture phase so this runs before postr-4tab.js's own lightbox handler.
  grids.forEach(function (g) {
    g.addEventListener("click", function (e) {
      var trigger = e.target.closest("[data-postr-lightbox-src]");
      if (!trigger) return;
      var card = trigger.closest(".postr-card");
      if (!card) return;
      e.preventDefault();
      e.stopPropagation();
      openModal(card);
    }, true);
  });

  // Fill the combined design count in the panel head.
  var totalEl = document.querySelector("[data-postr-total-count]");
  if (totalEl) totalEl.textContent = cards.length + " designs";

  if (matched === 0 && cards.length) {
    console.warn("Postr catalogue: no cards matched catalogue entries. Check display names against snippets/postr-catalogue.liquid.");
  }
})();
