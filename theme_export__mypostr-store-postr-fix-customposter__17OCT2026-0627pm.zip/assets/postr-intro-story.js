document.addEventListener("DOMContentLoaded", () => {
  const intro = document.querySelector("[data-postr-story-intro]");
  if (!intro) return;

  const stage = intro.querySelector(".postr-story-stage");
  const word = intro.querySelector("[data-story-word]");
  const dot = intro.querySelector("[data-story-dot]");
  const letters = [...intro.querySelectorAll(".postr-story-letter:not(.postr-story-remove)")];

  // Show only once per session.
  if (sessionStorage.getItem("postrStoryIntroPlayed") === "true") {
    intro.remove();
    return;
  }

  document.documentElement.classList.add("postr-intro-running");
  document.body.style.overflow = "hidden";

  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));

  function getDotDestinationLeft() {
    const rLetter = letters[letters.length - 1];
    if (!rLetter) return 0;

    const wordRect = word.getBoundingClientRect();
    const rRect = rLetter.getBoundingClientRect();

    // Land just after the R.
    return (rRect.right - wordRect.left) + 7;
  }

  async function bounceDotAcross() {
    intro.classList.add("phase-dot-ready");
    dot.classList.add("is-bouncing");

    await wait(100);

    const destination = getDotDestinationLeft();
    const start = parseFloat(getComputedStyle(dot).left) || -34;

    // 5 small left-to-right hops.
    const steps = 5;
    for (let i = 1; i <= steps; i++) {
      const t = i / steps;
      const eased = 1 - Math.pow(1 - t, 2);
      const x = start + (destination - start) * eased;

      dot.style.transition = "left .25s cubic-bezier(.2,.75,.25,1)";
      dot.style.left = `${x}px`;

      await wait(245);
    }

    dot.classList.remove("is-bouncing");
    dot.style.transition = "left .18s ease, transform .18s ease";
    dot.style.left = `${destination}px`;
    dot.style.transform = "translateY(0) scale(1)";
  }

  function findHeaderTarget() {
    return (
      document.querySelector(".postr-premium-header .header__heading-link") ||
      document.querySelector(".header-wrapper .header__heading-link") ||
      document.querySelector(".header__heading-link")
    );
  }

  async function flyToHeader() {
    const target = findHeaderTarget();

    if (!target) {
      stage.style.opacity = "0";
      await wait(300);
      return;
    }

    const stageRect = stage.getBoundingClientRect();
    const targetRect = target.getBoundingClientRect();

    const stageCenterX = stageRect.left + stageRect.width / 2;
    const stageCenterY = stageRect.top + stageRect.height / 2;

    const targetCenterX = targetRect.left + targetRect.width / 2;
    const targetCenterY = targetRect.top + targetRect.height / 2;

    const dx = targetCenterX - stageCenterX;
    const dy = targetCenterY - stageCenterY;

    // Scale intro lockup down to roughly header-logo size.
    const scale = Math.max(
      0.16,
      Math.min(0.32, targetRect.width / Math.max(stageRect.width, 1))
    );

    stage.classList.add("is-flying");

    requestAnimationFrame(() => {
      stage.style.transform = `translate(${dx}px, ${dy}px) scale(${scale})`;
      stage.style.opacity = "0";
    });

    await wait(900);
  }

  async function run() {
    // 1. logo appears
    intro.classList.add("phase-logo");
    await wait(650);

    // 2. POSTERS appears
    intro.classList.add("phase-posters");
    await wait(850);

    // 3. E + S leave -> POSTR
    intro.classList.add("phase-postr");
    await wait(560);

    // 4. Dot hops left-to-right and lands after R
    await bounceDotAcross();

    // 5. Brand settles as Postr.
    intro.classList.add("phase-settle");
    await wait(520);

    // 6. Whole lockup flies into the actual header brand position
    await flyToHeader();

    // 7. Reveal page
    intro.classList.add("is-done");
    document.body.style.overflow = "";
    document.documentElement.classList.remove("postr-intro-running");
    sessionStorage.setItem("postrStoryIntroPlayed", "true");

    await wait(520);
    intro.remove();
  }

  run();
});
