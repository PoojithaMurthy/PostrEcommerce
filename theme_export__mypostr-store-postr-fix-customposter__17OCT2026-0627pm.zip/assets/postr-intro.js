document.addEventListener("DOMContentLoaded",function(){
  const intro=document.getElementById("postr-intro");
  if(!intro)return;
  const alreadyPlayed=sessionStorage.getItem("postrIntroPlayed");
  if(alreadyPlayed){intro.remove();return;}
  document.body.style.overflow="hidden";
  setTimeout(function(){intro.classList.add("postr-intro-exit");},1900);
  setTimeout(function(){
    intro.style.opacity="0";
    intro.style.visibility="hidden";
    document.body.style.overflow="";
    sessionStorage.setItem("postrIntroPlayed","true");
    setTimeout(function(){intro.remove();},600);
  },2700);
});
