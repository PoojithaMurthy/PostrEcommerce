document.addEventListener("DOMContentLoaded", () => {
  // HARD HOME-PAGE GUARD:
  // Only run on exact homepage. Never on products, contact, cart, etc.
  const path = window.location.pathname.replace(/\/+$/, "") || "/";
  const isHomePath = path === "/";
  const isShopifyHome = document.body.classList.contains("template-index");

  if (!isHomePath && !isShopifyHome) {
    document.querySelectorAll("[data-postr-ppt-intro]").forEach(el => el.remove());
    return;
  }

  const intro = document.querySelector("[data-postr-ppt-intro]");
  if (!intro) return;

  // Once per browser session. This had no guard at all, so the animation
  // replayed on every single homepage visit — including every time someone
  // navigated back to the homepage mid-session.
  const SEEN_KEY = "postrPptIntroPlayed";
  let alreadyPlayed = false;
  try {
    alreadyPlayed = sessionStorage.getItem(SEEN_KEY) === "true";
  } catch (e) {
    // Private mode / blocked storage: fall through and play it.
  }
  if (alreadyPlayed) {
    intro.remove();
    return;
  }
  try {
    sessionStorage.setItem(SEEN_KEY, "true");
  } catch (e) {}

  const lockup = intro.querySelector("[data-postr-lockup]");
  const word = intro.querySelector("[data-postr-word]");
  const dot = intro.querySelector("[data-postr-dot]");
  const pLetter = intro.querySelector("[data-postr-p]");
  const eLetter = intro.querySelector("[data-postr-e]");
  const rLetter = intro.querySelector("[data-postr-r]");

  if (!lockup || !word || !dot || !pLetter || !eLetter || !rLetter) {
    intro.remove();
    return;
  }

  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
  document.body.style.overflow = "hidden";

  // Never trap the page.
  const failsafe = window.setTimeout(() => {
    document.body.style.overflow = "";
    intro.classList.add("is-finished");
    window.setTimeout(() => intro.remove(), 500);
  }, 9000);

  function geometry() {
    const wordRect = word.getBoundingClientRect();
    const pRect = pLetter.getBoundingClientRect();
    const eRect = eLetter.getBoundingClientRect();
    const rRect = rLetter.getBoundingClientRect();

    return {
      wordRect,
      pRect,
      eRect,
      rRect,
      pHeight: Math.max(pRect.height, 60),

      // Dot must occupy the exact ORIGINAL r slot.
      // left is calculated so the DOT'S CENTER aligns with the original r center.
      dotDestinationX:
        (rRect.left - wordRect.left) +
        (rRect.width / 2) -
        (dot.getBoundingClientRect().width / 2),

      // r moves to old e slot.
      rShiftX:
        eRect.left - rRect.left
    };
  }

  function setDotAt(x, y) {
    dot.style.left = `${x}px`;
    dot.style.transform = `translateY(${-y}px) scale(1)`;
  }

  function animateArc({
    startX,
    endX,
    height,
    duration,
    onProgress
  }) {
    return new Promise(resolve => {
      const startTime = performance.now();

      function frame(now) {
        const t = Math.min(1, (now - startTime) / duration);

        // Smooth horizontal easing.
        const easeX = 0.5 - 0.5 * Math.cos(Math.PI * t);
        const x = startX + (endX - startX) * easeX;

        // Positive-only smooth half-sine arc:
        // 0 -> peak -> 0, perfectly rounded at the top.
        const y = height * Math.sin(Math.PI * t);

        setDotAt(x, y);

        if (typeof onProgress === "function") {
          onProgress(t, x, y);
        }

        if (t < 1) {
          requestAnimationFrame(frame);
        } else {
          setDotAt(endX, 0);
          resolve();
        }
      }

      requestAnimationFrame(frame);
    });
  }

  async function animateBlackDot() {
    // Make dot measurable before calculating its exact final x.
    dot.style.opacity = "0";
    dot.style.visibility = "hidden";
    dot.style.left = "-9999px";
    dot.style.transform = "translateY(0) scale(1)";

    // Force layout so getBoundingClientRect() returns the true dot width.
    void dot.offsetWidth;

    const g = geometry();

    rLetter.style.setProperty("--postr-r-shift", `${g.rShiftX}px`);

    const startX =
      (g.pRect.left - g.wordRect.left) - 42;

    const destinationX =
      g.dotDestinationX;

    dot.style.left = `${startX}px`;
    dot.style.visibility = "visible";
    dot.style.opacity = "1";
    dot.style.transform = "translateY(0)";
    intro.classList.add("phase-dot");

    // Requested bounce heights:
    // 1.5P, 1.2P, 1.0P, .75P, .5P, .25P
    const multipliers = [1.50, 1.20, 1.00, 0.75, 0.50, 0.25];

    // Slower overall horizontal progression.
    const checkpoints = [0.18, 0.35, 0.52, 0.68, 0.84, 1.00];

    // Around half previous speed => roughly double duration.
    // 4 SECOND VERSION: six smooth arcs complete in about 2.05 seconds total.
    const durations = [370, 355, 345, 335, 325, 315];

    let prevX = startX;

    for (let i = 0; i < multipliers.length; i++) {
      const nextX =
        startX +
        (destinationX - startX) *
        checkpoints[i];

      const height =
        g.pHeight * multipliers[i];

      await animateArc({
        startX: prevX,
        endX: nextX,
        height,
        duration: durations[i],
        onProgress: (t) => {
          /*
            MORPH TIMING

            After first bounce:
            e begins fading.

            During second bounce:
            by its peak (t ≈ .5),
            e is fully gone and r is already moving left.
          */
          if (i === 0 && t > 0.68) {
            intro.classList.add("phase-morph-start");
          }

          if (i === 1) {
            // Smoothly drive e opacity down during bounce 2.
            const fadeProgress = Math.min(1, t / 0.5);
            eLetter.style.opacity =
              String(0.68 * (1 - fadeProgress));

            // r starts moving left during same bounce.
            const rProgress =
              Math.min(0.72, fadeProgress * 0.72);

            rLetter.style.transform =
              `translateX(${g.rShiftX * rProgress}px)`;

            // At top of bounce 2: e fully vanished.
            if (t >= 0.5) {
              intro.classList.add("phase-morph-mid");
              eLetter.style.opacity = "0";
              eLetter.style.visibility = "hidden";
            }
          }
        }
      });

      prevX = nextX;
    }

    // Dot settles exactly in the original r slot.
    dot.style.transition = "none";
    dot.style.left = `${destinationX}px`;
    dot.style.transform = "translateY(0) scale(1)";
    dot.classList.add("is-settled");

    // Finish r movement into e's old slot.
    intro.classList.add("phase-morph-final");
    rLetter.style.transform = `translateX(${g.rShiftX}px)`;

    eLetter.style.opacity = "0";
    eLetter.style.visibility = "hidden";
    eLetter.setAttribute("aria-hidden", "true");

    // Force final geometry to be applied before the lockup flies to header.
    void word.offsetWidth;

    await wait(230);
  }

  function findHeaderTarget() {
    return (
      document.querySelector(".postr-premium-header .header__heading-link") ||
      document.querySelector(".header-wrapper .header__heading-link") ||
      document.querySelector(".header__heading-link")
    );
  }

  async function flyToHeader() {
    const target = findHeaderTarget();

    if (!target) {
      lockup.style.opacity = "0";
      await wait(220);
      return;
    }

    const source = lockup.getBoundingClientRect();
    const destination = target.getBoundingClientRect();

    const sourceX =
      source.left + source.width / 2;
    const sourceY =
      source.top + source.height / 2;

    const targetX =
      destination.left + destination.width / 2;
    const targetY =
      destination.top + destination.height / 2;

    const dx = targetX - sourceX;
    const dy = targetY - sourceY;

    const scale = Math.max(
      0.16,
      Math.min(
        0.31,
        destination.width /
        Math.max(source.width, 1)
      )
    );

    lockup.classList.add("is-flying");

    requestAnimationFrame(() => {
      lockup.style.transform =
        `translate(${dx}px,${dy}px) scale(${scale})`;
      lockup.style.opacity = "0";
    });

    await wait(520);
  }

  async function run() {
    try {
      // Logo
      intro.classList.add("phase-logo");
      await wait(500);

      // Correct starting word: Poster
      intro.classList.add("phase-poster");
      await wait(300);

      // Smooth damped-wave bounce + overlapping morph
      await animateBlackDot();

      // Final visual: Postr.
      intro.classList.add("phase-settle");
      await wait(300);

      // Fly to actual header logo
      await flyToHeader();

    } catch (error) {
      console.error("POSTR intro error:", error);
    } finally {
      window.clearTimeout(failsafe);
      intro.classList.add("is-finished");
      document.body.style.overflow = "";

      await wait(180);
      intro.remove();
    }
  }

  run();
});
