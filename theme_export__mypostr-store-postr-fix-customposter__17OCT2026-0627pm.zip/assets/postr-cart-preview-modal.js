(() => {
  "use strict";

  let overlay = null;
  let img = null;
  let lastFocused = null;

  function ensureOverlay() {
    if (overlay) return overlay;

    overlay = document.createElement("div");
    overlay.className = "postr-preview-overlay";
    overlay.setAttribute("role", "dialog");
    overlay.setAttribute("aria-modal", "true");
    overlay.setAttribute("aria-label", "Uploaded photo preview");

    const dialog = document.createElement("div");
    dialog.className = "postr-preview-overlay__dialog";

    img = document.createElement("img");
    img.className = "postr-preview-overlay__img";
    img.alt = "Uploaded photo preview";

    const closeButton = document.createElement("button");
    closeButton.type = "button";
    closeButton.className = "postr-preview-overlay__close";
    closeButton.setAttribute("aria-label", "Close preview");
    closeButton.textContent = "✕";
    closeButton.addEventListener("click", closePreview);

    dialog.append(img, closeButton);
    overlay.append(dialog);
    document.body.append(overlay);

    overlay.addEventListener("click", (event) => {
      if (event.target === overlay) closePreview();
    });

    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && overlay.classList.contains("is-open")) closePreview();
    });

    return overlay;
  }

  function openPreview(src) {
    if (!src) return;
    ensureOverlay();
    img.src = src;
    lastFocused = document.activeElement;
    overlay.classList.add("is-open");
    document.body.style.overflow = "hidden";
    const closeButton = overlay.querySelector(".postr-preview-overlay__close");
    if (closeButton) closeButton.focus();
  }

  function closePreview() {
    if (!overlay) return;
    overlay.classList.remove("is-open");
    document.body.style.overflow = "";
    img.src = "";
    if (lastFocused && typeof lastFocused.focus === "function") lastFocused.focus();
  }

  document.addEventListener("click", (event) => {
    const trigger = event.target.closest("[data-postr-preview-src]");
    if (!trigger) return;
    event.preventDefault();
    openPreview(trigger.getAttribute("data-postr-preview-src"));
  });
})();
