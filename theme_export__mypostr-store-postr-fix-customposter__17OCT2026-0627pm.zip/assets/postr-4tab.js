document.addEventListener("DOMContentLoaded", function () {
  const shell = document.querySelector("[data-postr-4tab-shell]");
  if (!shell) return;

  const endpoint = (shell.dataset.uploadEndpoint || "").trim();
  const moneyGlobal = cents => "₹" + Math.round(Number(cents || 0) / 100);

  const CART_UPDATE_SECTIONS = ["cart-drawer", "cart-icon-bubble"];

  // Update the header count from the cart/add.js response we already have.
  // The old code fired a second fetch("cart.js") round-trip for a number the
  // add response had already returned — that extra request was the visible lag.
  function setCartCount(count) {
    const n = Number(count);
    if (!Number.isFinite(n)) return;
    document.querySelectorAll(".cart-count-bubble").forEach(bubble => {
      const target = bubble.querySelector("[data-cart-count]") || bubble.querySelector("span[aria-hidden]");
      if (target) target.textContent = n < 100 ? n : "99+";
      bubble.toggleAttribute("data-cart-empty", n === 0);
    });
  }

  // cart/add.js does not return item_count, but we request the
  // "cart-icon-bubble" section with the add, so the freshly-rendered count is
  // already in the response. Read it from there instead of re-fetching.
  function countFromSections(response) {
    const html = response && response.sections && response.sections["cart-icon-bubble"];
    if (!html) return null;
    const doc = new DOMParser().parseFromString(html, "text/html");
    const el = doc.querySelector("[data-cart-count]") || doc.querySelector(".cart-count-bubble span[aria-hidden]");
    if (!el) return null;
    const n = parseInt((el.textContent || "").replace(/\D/g, ""), 10);
    return Number.isFinite(n) ? n : null;
  }

  function notifyCartUpdated(cartAddResponse) {
    const fromSections = countFromSections(cartAddResponse);
    if (fromSections !== null) setCartCount(fromSections);

    // Adding goes straight to the cart page. There is no side drawer: the
    // customer sees the real cart, with their photo preview, in one step.
    goToCart();
  }

  function goToCart() {
    window.location.href = (window.Shopify?.routes?.root || "/") + "cart";
  }
  const buttons = [...document.querySelectorAll("[data-postr-tab-button]")];
  const panels = [...document.querySelectorAll("[data-postr-tab-panel]")];

  function showTab(name) {
    buttons.forEach(b => {
      const on = b.dataset.postrTabButton === name;
      b.classList.toggle("is-active", on);
      b.setAttribute("aria-selected", on ? "true" : "false");
    });
    panels.forEach(p => p.hidden = p.dataset.postrTabPanel !== name);
  }

  function tabFromLocation() {
    const params = new URLSearchParams(window.location.search);
    const raw = (params.get("tab") || window.location.hash.replace(/^#/, "") || "").toLowerCase().trim();
    // Old links (?tab=movies, ?tab=polaroids) still resolve — the tabs were
    // restructured to Posters / Custom / Combo Packs, but inbound URLs,
    // bookmarks and older homepage cards must not 404 into an empty view.
    const aliases = {
      posters: "posters",
      poster: "posters",
      movies: "posters",
      movie: "posters",
      series: "posters",
      sports: "posters",
      others: "posters",
      generic: "posters",
      custom: "custom",
      polaroids: "custom",
      polaroid: "custom",
      lights: "custom",
      accessories: "custom",
      combo: "combo",
      packs: "combo",
      pack: "combo",
      birthday: "combo",
    };
    return aliases[raw] || null;
  }

  buttons.forEach((b) =>
    b.addEventListener("click", () => {
      const name = b.dataset.postrTabButton;
      showTab(name);
      try {
        const url = new URL(window.location.href);
        url.searchParams.set("tab", name);
        url.hash = "";
        window.history.replaceState({}, "", url.pathname + url.search);
      } catch (e) {}
    })
  );
  showTab(tabFromLocation() || "posters");

  // Theme editor: selecting a section automatically opens its tab.
  document.addEventListener("shopify:section:select", function(e) {
    const selected = e.target && e.target.matches("[data-postr-tab-panel]") ? e.target : e.target?.querySelector?.("[data-postr-tab-panel]");
    if (selected) showTab(selected.dataset.postrTabPanel);
  });

  // The headline price is the line total (unit x quantity), with the unit price
  // shown beneath it once quantity passes 1 — so "2" reads as 180, not 90.
  function unitPriceOf(card) {
    const active = card.querySelector("[data-ready-size].is-active") || card.querySelector("[data-ready-size]");
    return Number(active?.dataset.price || 0);
  }

  function refreshCardPrice(card) {
    const priceEl = card.querySelector("[data-ready-price]");
    if (!priceEl) return;
    const qtyInput = card.querySelector("[data-ready-qty]");
    const qty = Math.max(1, Number(qtyInput?.value || 1));
    const unit = unitPriceOf(card);

    priceEl.textContent = moneyGlobal(unit * qty) + "/-";

    let each = card.querySelector("[data-ready-each]");
    if (!each) {
      each = document.createElement("small");
      each.className = "postr-ready-each";
      each.setAttribute("data-ready-each", "");
      priceEl.insertAdjacentElement("afterend", each);
    }
    if (qty > 1) {
      each.textContent = moneyGlobal(unit) + "/- each x " + qty;
      each.hidden = false;
    } else {
      each.hidden = true;
    }
  }

  // quantity for ready products
  document.querySelectorAll(".postr-card").forEach(card => {
    const minus = card.querySelector("[data-ready-minus]");
    const plus = card.querySelector("[data-ready-plus]");
    const qty = card.querySelector("[data-ready-qty]");
    if (!qty) return;
    const step = delta => {
      qty.value = Math.max(1, Number(qty.value || 1) + delta);
      refreshCardPrice(card);
    };
    minus?.addEventListener("click", () => step(-1));
    plus?.addEventListener("click", () => step(1));
    qty.addEventListener("input", () => refreshCardPrice(card));
    qty.addEventListener("change", () => {
      qty.value = Math.max(1, Number(qty.value || 1));
      refreshCardPrice(card);
    });
    refreshCardPrice(card);
  });


  document.querySelectorAll("[data-ready-size]").forEach(sizeBtn => {
    sizeBtn.addEventListener("click", () => {
      const card = sizeBtn.closest(".postr-card");
      card.querySelectorAll("[data-ready-size]").forEach(x => x.classList.remove("is-active"));
      sizeBtn.classList.add("is-active");

      const addBtn = card.querySelector("[data-ready-add]");
      if (addBtn) {
        addBtn.dataset.variantId = sizeBtn.dataset.variantId;
        addBtn.dataset.selectedSize = sizeBtn.dataset.size || "";
      }
      refreshCardPrice(card);
    });
  });

  // Let the detail popup recalculate the same way after it changes quantity.
  document.addEventListener("postr:qty-changed", e => {
    if (e.detail?.card) refreshCardPrice(e.detail.card);
  });

document.querySelectorAll("[data-ready-add]").forEach(btn => {
    btn.addEventListener("click", async () => {
      const card = btn.closest(".postr-card");
      const qty = card.querySelector("[data-ready-qty]");
      btn.disabled = true; btn.textContent = "Adding...";
      try {
        const res = await fetch(window.Shopify.routes.root + "cart/add.js", {
          method:"POST",
          headers:{"Content-Type":"application/json","Accept":"application/json"},
          body:JSON.stringify({
            items:[{
              id:Number(btn.dataset.variantId),
              quantity:Math.max(1,Number(qty.value||1)),
              properties:Object.assign(
                {
                  "Poster Design":btn.dataset.posterName || "Poster",
                  "Poster Size":btn.dataset.selectedSize || "A4",
                  "Poster Type":btn.dataset.posterType || "Poster",
                  "_Poster Image":btn.dataset.posterImage || ""
                },
                // Only ready-made catalogue designs carry a code.
                btn.dataset.posterCode ? { "Poster Code": btn.dataset.posterCode } : {}
              )
            }],
            sections: CART_UPDATE_SECTIONS,
            sections_url: window.location.pathname
          })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.description || "Could not add product.");
        notifyCartUpdated(data);
        btn.textContent = "Added ✓";
        setTimeout(()=>{btn.disabled=false;btn.textContent="Add to Cart";},1200);
      } catch(e) {
        alert(e.message); btn.disabled=false; btn.textContent="Add to Cart";
      }
    });
  });

  const overlay = shell.querySelector("[data-customizer-overlay]");
  const title = shell.querySelector("[data-customizer-title]");
  const posterStep = shell.querySelector("[data-poster-step]");
  const posterHelp = shell.querySelector("[data-poster-help]");
  const posterGrid = shell.querySelector("[data-poster-grid]");
  const polaroidStep = shell.querySelector("[data-polaroid-step]");
  const polaroidTitle = shell.querySelector("[data-polaroid-step-title]");
  const polaroidHelp = shell.querySelector("[data-polaroid-help]");
  const polaroidGrid = shell.querySelector("[data-polaroid-grid]");
  const polaroidMulti = shell.querySelector("[data-polaroid-multi]");
  const polaroidMultiBtn = shell.querySelector("[data-polaroid-multi-btn]");
  const polaroidMultiInput = shell.querySelector("[data-polaroid-multi-input]");
  const qty = shell.querySelector("[data-custom-qty]");
  const itemPrice = shell.querySelector("[data-price-item]");
  const totalPrice = shell.querySelector("[data-price-total]");
  const packMessageOption = shell.querySelector("[data-pack-message-option]");
  const packMessage = shell.querySelector("[data-pack-message]");
  const finish = shell.querySelector("[data-finish]");
  const addCustom = shell.querySelector("[data-add-custom]");
  const posterExtra = shell.querySelector("[data-poster-extra]");
  const posterTitleInput = shell.querySelector("[data-poster-title]");
  const quantityOption = shell.querySelector("[data-quantity-option]");
  const quantityHelp = shell.querySelector("[data-quantity-help]");
  const quantityLabel = shell.querySelector("[data-quantity-label]");

  let current = null, posterFiles = [], polaroidFiles = [];
  let digitalMemoryChoice = null;
  const money = cents => "₹" + Math.round(Number(cents || 0) / 100);
  const memoryButtons = [...shell.querySelectorAll("[data-memory-value]")];
  const memoryError = shell.querySelector("[data-memory-error]");

  function resetDigitalMemory() {
    digitalMemoryChoice = null;
    memoryButtons.forEach((btn) => {
      btn.classList.remove("is-active");
      btn.setAttribute("aria-pressed", "false");
    });
    if (memoryError) memoryError.hidden = true;
  }

  function setDigitalMemory(value) {
    digitalMemoryChoice = value;
    memoryButtons.forEach((btn) => {
      const active = btn.dataset.memoryValue === value;
      btn.classList.toggle("is-active", active);
      btn.setAttribute("aria-pressed", active ? "true" : "false");
    });
    if (memoryError) memoryError.hidden = true;
  }

  memoryButtons.forEach((btn) => {
    btn.addEventListener("click", () => setDigitalMemory(btn.dataset.memoryValue));
  });

  function createCustomizationId() {
    const cryptoApi = window.crypto;
    if (cryptoApi?.randomUUID) return cryptoApi.randomUUID();
    if (!cryptoApi?.getRandomValues) {
      throw new Error("Secure customization IDs are not supported by this browser.");
    }
    const bytes = new Uint8Array(16);
    cryptoApi.getRandomValues(bytes);
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    const hex = [...bytes].map((byte) => byte.toString(16).padStart(2, "0"));
    return [
      hex.slice(0, 4).join(""),
      hex.slice(4, 6).join(""),
      hex.slice(6, 8).join(""),
      hex.slice(8, 10).join(""),
      hex.slice(10, 16).join("")
    ].join("-");
  }

  function ensureLightbox() {
    let box = document.querySelector("[data-postr-lightbox]");
    if (box) return box;
    box = document.createElement("div");
    box.className = "postr-lightbox";
    box.hidden = true;
    box.setAttribute("data-postr-lightbox", "");
    box.innerHTML = `
      <button type="button" class="postr-lightbox__close" data-postr-lightbox-close aria-label="Close image">&times;</button>
      <img class="postr-lightbox__img" data-postr-lightbox-img alt="">
    `;
    document.body.appendChild(box);
    const close = () => {
      box.hidden = true;
      document.body.style.overflow = box.dataset.prevOverflow || "";
    };
    box.addEventListener("click", (e) => {
      if (e.target === box || e.target.closest("[data-postr-lightbox-close]")) close();
    });
    document.addEventListener("keydown", (e) => {
      if (!box.hidden && e.key === "Escape") close();
    });
    return box;
  }

  function openLightbox(src, alt) {
    if (!src) return;
    const box = ensureLightbox();
    const img = box.querySelector("[data-postr-lightbox-img]");
    img.src = src;
    img.alt = alt || "Poster preview";
    box.dataset.prevOverflow = document.body.style.overflow || "";
    box.hidden = false;
    document.body.style.overflow = "hidden";
  }

  document.querySelectorAll("[data-postr-lightbox-src]").forEach((btn) => {
    btn.addEventListener("click", () => {
      openLightbox(btn.getAttribute("data-postr-lightbox-src"), btn.getAttribute("data-postr-lightbox-alt") || "");
    });
  });

  async function fileToThumbDataUrl(file, maxSize = 180) {
    if (!file) return "";
    const MAX_CHARS = 14000;
    const attempts = [
      { size: maxSize, quality: 0.62 },
      { size: 140, quality: 0.5 },
      { size: 110, quality: 0.42 },
      { size: 80, quality: 0.36 }
    ];

    return new Promise((resolve) => {
      const objectUrl = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        URL.revokeObjectURL(objectUrl);
        try {
          for (const attempt of attempts) {
            const scale = Math.min(1, attempt.size / Math.max(img.width, img.height));
            const w = Math.max(1, Math.round(img.width * scale));
            const h = Math.max(1, Math.round(img.height * scale));
            const canvas = document.createElement("canvas");
            canvas.width = w;
            canvas.height = h;
            canvas.getContext("2d").drawImage(img, 0, 0, w, h);
            const data = canvas.toDataURL("image/jpeg", attempt.quality);
            if (data && data.indexOf("data:image") === 0 && data.length < MAX_CHARS) {
              resolve(data);
              return;
            }
          }
          resolve("");
        } catch (e) {
          resolve("");
        }
      };
      img.onerror = () => {
        URL.revokeObjectURL(objectUrl);
        resolve("");
      };
      img.src = objectUrl;
    });
  }

    async function saveDigitalMemoryAttribute(value) {
    const attrValue = value === "Yes" ? "Yes" : "";
    try {
      await fetch(window.Shopify.routes.root + "cart/update.js", {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ attributes: { "Digital Memory QR": attrValue } }),
      });
    } catch (e) {
      console.error("POSTR Digital Memory attribute:", e);
    }
  }

  function slot(index, role) {
    const label = document.createElement("label");
    label.className = "postr-photo-slot";

    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/jpeg,image/png,image/webp";

    const ph = document.createElement("div");
    ph.className = "postr-photo-placeholder";
    ph.innerHTML = `<b>+</b><small>${role === "poster" ? "Poster" : "Polaroid"} ${index + 1}</small>`;

    const img = document.createElement("img");
    img.hidden = true;

    input.addEventListener("change", () => {
      const file = input.files[0];
      if (!file) return;
      if (file.size > 10 * 1024 * 1024) {
        alert("Maximum file size is 10MB.");
        input.value = "";
        return;
      }

      img.src = URL.createObjectURL(file);
      img.hidden = false;
      ph.hidden = true;

      if (role === "poster") posterFiles[index] = file;
      else polaroidFiles[index] = file;
    });

    const existingFile =
      role === "poster"
        ? posterFiles[index]
        : polaroidFiles[index];

    if (existingFile) {
      img.src = URL.createObjectURL(existingFile);
      img.hidden = false;
      ph.hidden = true;
    }

    label.append(input, ph, img);
    return label;
  }

  function posterUploadCard(index) {
    const wrap = document.createElement("div");
    wrap.className = "postr-poster-upload-card";

    const title = document.createElement("div");
    title.className = "postr-poster-upload-card__title";
    title.textContent = `Poster ${index + 1}`;

    const photo = slot(index, "poster");

    const sizeWrap = document.createElement("div");
    sizeWrap.className = "postr-pack-size";

    const label = document.createElement("span");
    label.textContent = "Poster size";

    const buttons = document.createElement("div");
    buttons.className = "postr-size-buttons";

    const sizes = [
      { value:"A4", label:"A4" },
      { value:"A3", label:"A3" },
      { value:"13x19", label:"13×19" }
    ];

    sizes.forEach((size, idx) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.dataset.packPosterSize = size.value;
      btn.dataset.posterIndex = String(index);
      const selectedSize = current?.posterSizes?.[index] || "A4";
      if (size.value === selectedSize) btn.classList.add("is-active");

      if (current?.mode === "custom-poster") {
        const variantId =
          size.value === "A4" ? current.a4VariantId :
          size.value === "A3" ? current.a3VariantId :
          current.size13x19VariantId;

        const sizePrice =
          size.value === "A4" ? current.a4Price :
          size.value === "A3" ? current.a3Price :
          current.size13x19Price;

        btn.innerHTML = sizePrice > 0
          ? `${size.label} <small>${money(sizePrice)}</small>`
          : size.label;

        if (!variantId) {
          btn.disabled = true;
          btn.title = `${size.label} variant is not configured for this product.`;
        }
      } else if (current?.mode === "pack") {
        const upgradeVariantId =
          size.value === "A4" ? 1 :
          size.value === "A3" ? current.a3UpgradeVariantId :
          current.size13x19UpgradeVariantId;

        const upgradePrice =
          size.value === "A4" ? 0 :
          size.value === "A3" ? current.a3UpgradePrice :
          current.size13x19UpgradePrice;

        btn.innerHTML = upgradePrice > 0
          ? `${size.label} <small>+${money(upgradePrice)}</small>`
          : size.label;

        if (size.value !== "A4" && !upgradeVariantId) {
          btn.disabled = true;
          btn.title = `${size.label} upgrade product is not configured for this pack.`;
        }
      } else {
        btn.textContent = size.label;
      }

      btn.addEventListener("click", () => {
        buttons.querySelectorAll("[data-pack-poster-size]").forEach(x => x.classList.remove("is-active"));
        btn.classList.add("is-active");
        current.posterSizes[index] = size.value;

        if (current.mode === "custom-poster") {
          if (size.value === "A4") {
            current.variantId = current.a4VariantId;
            current.price = current.a4Price;
          } else if (size.value === "A3") {
            current.variantId = current.a3VariantId;
            current.price = current.a3Price;
          } else {
            current.variantId = current.size13x19VariantId;
            current.price = current.size13x19Price;
          }
        }

        updatePrice();
      });

      buttons.appendChild(btn);
    });

    if (!current.posterSizes[index]) {
      current.posterSizes[index] =
        current.a4VariantId ? "A4" :
        current.a3VariantId ? "A3" :
        "13x19";
    }

    sizeWrap.append(label, buttons);
    wrap.append(title, photo, sizeWrap);
    return wrap;
  }

  function buildGrid(container, count, role) {
    container.innerHTML = "";
    for (let i = 0; i < count; i++) {
      container.appendChild(role === "poster" ? posterUploadCard(i) : slot(i, role));
    }
  }

  function updatePolaroidMultiUi() {
    if (!polaroidMulti) return;
    const show = Boolean(current && !polaroidStep.hidden && Number(current.polaroidCount || 0) > 1);
    polaroidMulti.hidden = !show;
    if (polaroidMultiBtn) {
      const n = Number(current?.polaroidCount || 0);
      polaroidMultiBtn.textContent = n > 1 ? `Select up to ${n} photos at once` : "Select multiple photos";
    }
    if (polaroidMultiInput) {
      polaroidMultiInput.value = "";
      if (show) polaroidMultiInput.setAttribute("multiple", "");
    }
  }

  function applyPolaroidBatch(fileList) {
    if (!current || !current.polaroidCount) return;
    const needed = Math.max(1, Number(current.polaroidCount || 1));
    const incoming = [...(fileList || [])].filter(Boolean);
    if (!incoming.length) return;

    const accepted = [];
    for (const file of incoming) {
      if (file.size > 10 * 1024 * 1024) {
        alert(`“${file.name || "A file"}” is over 10MB and was skipped.`);
        continue;
      }
      if (!/^image\/(jpeg|png|webp)$/i.test(file.type || "")) {
        alert(`“${file.name || "A file"}” is not a supported image and was skipped.`);
        continue;
      }
      accepted.push(file);
      if (accepted.length >= needed) break;
    }

    if (!accepted.length) return;

    if (incoming.length > needed) {
      alert(`You selected ${incoming.length} photos. Only the first ${needed} were used.`);
    }

    polaroidFiles = Array.from({ length: needed }, (_, i) => accepted[i] || null);

    buildGrid(polaroidGrid, needed, "polaroid");
    updatePolaroidMultiUi();

    const filled = polaroidFiles.filter(Boolean).length;
    if (polaroidHelp) {
      polaroidHelp.textContent = filled >= needed
        ? `All ${needed} Polaroid photo(s) selected. You can still tap a slot to replace one.`
        : `${filled} of ${needed} photo(s) selected. Add ${needed - filled} more, or use “Select multiple photos” again.`;
    }
  }

  if (polaroidMultiBtn && polaroidMultiInput) {
    polaroidMultiBtn.addEventListener("click", () => polaroidMultiInput.click());
    polaroidMultiInput.addEventListener("change", () => {
      applyPolaroidBatch(polaroidMultiInput.files);
      polaroidMultiInput.value = "";
    });
  }

  function customPosterVariantForSize(size) {
    if (!current) return 0;
    if (size === "A3") return current.a3VariantId;
    if (size === "13x19") return current.size13x19VariantId;
    return current.a4VariantId;
  }

  function customPosterPriceForSize(size) {
    if (!current) return 0;
    if (size === "A3") return current.a3Price;
    if (size === "13x19") return current.size13x19Price;
    return current.a4Price;
  }

  function updatePrice() {
    if (!current) return;

    const q = Math.max(1, Number(qty.value || 1));

    if (current.mode === "custom-poster") {
      const sizes = current.posterSizes.length
        ? current.posterSizes
        : Array(q).fill("A4");

      const total = sizes.reduce(
        (sum, size) => sum + Number(customPosterPriceForSize(size) || 0),
        0
      );

      const firstPrice = sizes.length
        ? customPosterPriceForSize(sizes[0])
        : current.price;

      itemPrice.textContent = money(firstPrice);
      totalPrice.textContent = money(total);
      return;
    }

    let perItem = current.price;

    if (current.mode === "pack") {
      const a3Count = current.posterSizes.filter(size => size === "A3").length;
      const size13x19Count = current.posterSizes.filter(size => size === "13x19").length;
      perItem += a3Count * current.a3UpgradePrice;
      perItem += size13x19Count * current.size13x19UpgradePrice;
    }

    itemPrice.textContent = money(perItem);
    totalPrice.textContent = money(perItem * q);
  }

  document.querySelectorAll("[data-open-customizer]").forEach(btn => {
    btn.addEventListener("click", () => {
      posterFiles = []; polaroidFiles = [];
      current = {
        mode:btn.dataset.mode,
        title:btn.dataset.title,
        variantId:Number(btn.dataset.variantId),
        price:Number(btn.dataset.price),
        posterCount:Number(btn.dataset.posterCount || 0),
        polaroidCount:Number(btn.dataset.polaroidCount || 0),
        a4VariantId:Number(btn.dataset.a4VariantId || 0),
        a4Price:Number(btn.dataset.a4Price || 0),
        a3VariantId:Number(btn.dataset.a3VariantId || 0),
        a3Price:Number(btn.dataset.a3Price || 0),
        size13x19VariantId:Number(btn.dataset['13x19VariantId'] || 0),
        size13x19Price:Number(btn.dataset['13x19Price'] || 0),
        a3UpgradeVariantId:Number(btn.dataset.a3UpgradeVariantId || 0),
        a3UpgradePrice:Number(btn.dataset.a3UpgradePrice || 0),
        size13x19UpgradeVariantId:Number(btn.dataset['13x19UpgradeVariantId'] || 0),
        size13x19UpgradePrice:Number(btn.dataset['13x19UpgradePrice'] || 0),
        posterSizes:[],
        customizationId: createCustomizationId()
      };

      current.posterSizes = Array(current.posterCount).fill("A4");

      if (current.mode === "custom-poster") {
        current.posterCount = 1;

        if (current.a4VariantId) {
          current.variantId = current.a4VariantId;
          current.price = current.a4Price;
          current.posterSizes = ["A4"];
        } else if (current.a3VariantId) {
          current.variantId = current.a3VariantId;
          current.price = current.a3Price;
          current.posterSizes = ["A3"];
        } else if (current.size13x19VariantId) {
          current.variantId = current.size13x19VariantId;
          current.price = current.size13x19Price;
          current.posterSizes = ["13x19"];
        }
      }

      title.textContent = current.title;
      qty.value = 1;
      if (packMessage) packMessage.value = "";

      posterStep.hidden = current.posterCount === 0;
      polaroidStep.hidden = current.polaroidCount === 0;

      if (current.posterCount > 0) {
        posterHelp.textContent = `Upload exactly ${current.posterCount} poster photo(s).`;
        buildGrid(posterGrid, current.posterCount, "poster");
      }
      if (current.polaroidCount > 0) {
        polaroidTitle.textContent = current.posterCount > 0 ? "2. Polaroid Photos" : "1. Polaroid Photos";
        polaroidHelp.textContent = current.polaroidCount > 1
          ? `Upload exactly ${current.polaroidCount} Polaroid photo(s). Tip: use “Select multiple photos” to pick them all at once.`
          : `Upload exactly ${current.polaroidCount} Polaroid photo(s).`;
        buildGrid(polaroidGrid, current.polaroidCount, "polaroid");
      }
      updatePolaroidMultiUi();
      const isCustomPoster = current.mode === "custom-poster";
      const isDynamicPolaroid = current.mode === "polaroid-dynamic";
      const isLightPolaroid = current.mode === "light-polaroid";

      if (posterExtra) posterExtra.hidden = !isCustomPoster;
      if (packMessageOption) packMessageOption.hidden = current.mode !== "pack";
      if (posterTitleInput) posterTitleInput.value = "";

      if (quantityOption) quantityOption.hidden = isLightPolaroid;
      if (quantityLabel) {
        quantityLabel.textContent =
          isDynamicPolaroid ? "Number of Polaroids" :
          isCustomPoster ? "Number of Posters" :
          "Quantity";
      }
      if (quantityHelp) {
        if (isDynamicPolaroid) {
          quantityHelp.hidden = false;
          quantityHelp.textContent = "Price is calculated per Polaroid. Upload boxes update to match the quantity you select.";
        } else if (isCustomPoster) {
          quantityHelp.hidden = false;
          quantityHelp.textContent = "Price is per poster. Upload boxes update to match the quantity, and you pick a size for each one.";
        } else {
          quantityHelp.hidden = true;
          quantityHelp.textContent = "";
        }
      }

      if (isDynamicPolaroid) {
        current.polaroidCount = 1;
        polaroidTitle.textContent = "1. Upload Polaroid Photos";
        polaroidHelp.textContent = "Upload 1 photo for 1 Polaroid. Increase quantity to upload more — then use “Select multiple photos”.";
        buildGrid(polaroidGrid, 1, "polaroid");
        updatePolaroidMultiUi();
      }

      if (isLightPolaroid) {
        qty.value = 1;
        current.polaroidCount = 10;
        polaroidTitle.textContent = "1. Upload 10 Polaroid Photos";
        polaroidHelp.textContent = "This pack is fixed at 10 Polaroids with light clips. Use “Select multiple photos” to upload all 10 at once.";
        buildGrid(polaroidGrid, 10, "polaroid");
        updatePolaroidMultiUi();
      }


      overlay.hidden = false;
      document.body.style.overflow = "hidden";
      resetDigitalMemory();
      updatePrice();
    });
  });


  function closeCustomizer() {
    overlay.hidden = true;
    document.body.style.overflow = "";
    current = null;
  }

  shell.querySelector("[data-close-customizer]").addEventListener("click", closeCustomizer);
  overlay.addEventListener("click", e => { if (e.target === overlay) closeCustomizer(); });

  function syncCustomPosterUploads() {
    if (!current || current.mode !== "custom-poster") return;

    const count = Math.max(1, Number(qty.value || 1));
    const defaultSize =
      current.a4VariantId ? "A4" :
      current.a3VariantId ? "A3" :
      "13x19";

    const previousSizes = Array.isArray(current.posterSizes)
      ? [...current.posterSizes]
      : [];

    const previousFiles = Array.isArray(posterFiles)
      ? [...posterFiles]
      : [];

    current.posterCount = count;
    current.posterSizes = Array.from(
      { length: count },
      (_, index) => previousSizes[index] || defaultSize
    );

    posterFiles = Array.from(
      { length: count },
      (_, index) => previousFiles[index] || null
    );

    posterStep.hidden = false;
    posterHelp.textContent = `Upload exactly ${count} poster photo(s).`;
    buildGrid(posterGrid, count, "poster");
  }

  function syncDynamicPolaroidUploads() {
    if (!current || current.mode !== "polaroid-dynamic") return;
    const count = Math.max(1, Number(qty.value || 1));
    const previous = Array.isArray(polaroidFiles) ? [...polaroidFiles] : [];
    current.polaroidCount = count;
    polaroidFiles = Array.from({ length: count }, (_, i) => previous[i] || null);
    polaroidTitle.textContent = "1. Upload Polaroid Photos";
    polaroidHelp.textContent = count > 1
      ? `Upload exactly ${count} photo(s) for ${count} Polaroid(s). Tip: use “Select multiple photos”.`
      : `Upload exactly ${count} photo(s) for ${count} Polaroid(s).`;
    buildGrid(polaroidGrid, count, "polaroid");
    updatePolaroidMultiUi();
  }

  shell.querySelector("[data-custom-minus]").addEventListener("click", () => {
    qty.value = Math.max(1, Number(qty.value || 1) - 1);
    syncCustomPosterUploads();
    syncDynamicPolaroidUploads();
    updatePrice();
  });
  shell.querySelector("[data-custom-plus]").addEventListener("click", () => {
    qty.value = Math.max(1, Number(qty.value || 1) + 1);
    syncCustomPosterUploads();
    syncDynamicPolaroidUploads();
    updatePrice();
  });
  qty.addEventListener("change", () => {
    qty.value = Math.max(1, Number(qty.value || 1));
    syncCustomPosterUploads();
    syncDynamicPolaroidUploads();
    updatePrice();
  });

  async function uploadFile(file, role, customizationId) {
    if (!endpoint) throw new Error("Cloudflare upload URL is not configured yet.");
    if (!customizationId) throw new Error("Missing customization ID for upload.");
    const form = new FormData();
    form.append("file", file);
    form.append("role", role);
    form.append("customizationId", customizationId);
    const res = await fetch(endpoint, {method:"POST", body:form});
    let data = {};
    try { data = await res.json(); } catch (e) { data = {}; }
    if (!res.ok) throw new Error(data.error || "Upload failed. Please try again.");
    const key = data.key || data.id || data.fileKey || "";
    let url =
      data.url ||
      data.publicUrl ||
      data.cdnUrl ||
      data.previewUrl ||
      data.imageUrl ||
      data.fileUrl ||
      "";
    if (!url && typeof key === "string" && (key.indexOf("http") === 0 || key.indexOf("//") === 0 || key.indexOf("data:image") === 0)) {
      url = key;
    }
    return { key: key || url, url: url || "" };
  }

  async function uploadMany(files, role, customizationId) {
    const refs = [];
    for (const f of files) if (f) refs.push(await uploadFile(f, role, customizationId));
    return refs;
  }

  function refKey(ref) {
    if (!ref) return "";
    if (typeof ref === "string") return ref;
    return ref.key || ref.url || "";
  }

  function refUrl(ref) {
    if (!ref) return "";
    if (typeof ref === "string") {
      if (ref.indexOf("http") === 0 || ref.indexOf("//") === 0 || ref.indexOf("data:image") === 0 || ref.indexOf("/cdn/") !== -1 || ref.indexOf("/uploads/") !== -1 || ref.indexOf("workers.dev") !== -1) {
        return ref;
      }
      return "";
    }
    if (ref.url) return String(ref.url);
    const key = ref.key ? String(ref.key) : "";
    if (key.indexOf("http") === 0 || key.indexOf("//") === 0 || key.indexOf("data:image") === 0) return key;
    return "";
  }

  addCustom.addEventListener("click", async () => {
    if (!current) return;
    if (digitalMemoryChoice !== "Yes" && digitalMemoryChoice !== "No") {
      if (memoryError) {
        memoryError.hidden = false;
        memoryError.scrollIntoView({ behavior: "smooth", block: "center" });
      }
      return;
    }
    if (posterFiles.filter(Boolean).length !== current.posterCount) {
      alert(`Please upload all ${current.posterCount} poster photo(s).`); return;
    }
    if (polaroidFiles.filter(Boolean).length !== current.polaroidCount) {
      alert(`Please upload all ${current.polaroidCount} Polaroid photo(s).`); return;
    }

    addCustom.disabled = true; addCustom.textContent = "Uploading...";
    try {
      const customizationId = current.customizationId || createCustomizationId();
      current.customizationId = customizationId;
      const posterRefs = await uploadMany(posterFiles, "poster", customizationId);
      const polaroidRefs = await uploadMany(polaroidFiles, "polaroid", customizationId);
      const memoryLabel = digitalMemoryChoice === "Yes" ? "Yes" : "No";
      const properties = {
        "Customization":"Yes",
        "Customization ID": customizationId,
        "Poster Files": posterRefs.map(refKey).filter(Boolean).join(", ") || "None",
        "Polaroid Files": polaroidRefs.map(refKey).filter(Boolean).join(", ") || "None",
        "Digital Memory": memoryLabel
      };

      const localFiles = [...posterFiles, ...polaroidFiles].filter(Boolean);
      const localThumbs = await Promise.all(localFiles.map((file) => fileToThumbDataUrl(file)));
      const remoteViewables = [
        ...posterRefs.map(refUrl).filter(Boolean),
        ...polaroidRefs.map(refUrl).filter(Boolean)
      ];
      const previewSources = [];
      remoteViewables.forEach((url) => {
        if (url && previewSources.indexOf(url) === -1) previewSources.push(url);
      });
      localThumbs.forEach((thumb) => {
        if (thumb && previewSources.indexOf(thumb) === -1) previewSources.push(thumb);
      });
      previewSources.forEach((src, index) => {
        properties[`_Design Preview ${index + 1}`] = src;
      });
      const httpOnlyPreviews = previewSources.filter((src) => src.indexOf("http") === 0 || src.indexOf("//") === 0);
      if (httpOnlyPreviews.length) {
        properties["_Poster Images"] = httpOnlyPreviews.join(", ");
      }
      let firstPosterImage = previewSources[0] || "";
      if (firstPosterImage) properties["_Poster Image"] = firstPosterImage;

      if (current.mode === "pack") {
        properties["Birthday Message"] = packMessage?.value.trim() || "None";
      }

      if (current.mode === "pack" && current.posterCount > 0) {
        current.posterSizes.forEach((size, index) => {
          properties[`Poster ${index + 1} Size`] = size;
        });
      }

      if (current.mode === "custom-poster") {
        properties["Poster Title"] = posterTitleInput?.value.trim() || "None";
      }

      addCustom.textContent = "Adding to Cart...";
      await saveDigitalMemoryAttribute(memoryLabel);

      const packQty = Math.max(1, Number(qty.value || 1));
      let cartItems = [];

      if (current.mode === "custom-poster") {
        const posterThumbs = await Promise.all(
          posterFiles.map((file) => (file ? fileToThumbDataUrl(file) : Promise.resolve("")))
        );
        cartItems = posterRefs.map((posterRef, index) => {
          const size = current.posterSizes[index] || "A4";
          const variantId = customPosterVariantForSize(size);

          if (!variantId) {
            throw new Error(`Shopify variant is not configured for ${size}.`);
          }

          const imageUrl = refUrl(posterRef);
          const fileKey = refKey(posterRef);
          const thumb = posterThumbs[index] || firstPosterImage || "";

          return {
            id: variantId,
            quantity: 1,
            properties: {
              "Customization": "Yes",
              "Customization ID": customizationId,
              "Poster File": fileKey,
              "_Poster Image": imageUrl || thumb,
              "_Design Preview 1": imageUrl || thumb,
              "Poster Number": String(index + 1),
              "Poster Title": posterTitleInput?.value.trim() || "None",
              "Poster Size": size,
              "Digital Memory": memoryLabel
            }
          };
        });
      } else {
        cartItems = [{ id: current.variantId, quantity: packQty, properties }];

        if (current.mode === "pack") {
          const a3Count = current.posterSizes.filter((size) => size === "A3").length;
          const size13x19Count = current.posterSizes.filter((size) => size === "13x19").length;

          if (a3Count > 0 && current.a3UpgradeVariantId) {
            cartItems.push({
              id: current.a3UpgradeVariantId,
              quantity: a3Count * packQty,
              properties: {
                "Upgrade For": current.title,
                "Upgrade Type": "A3 Poster Size"
              }
            });
          }

          if (size13x19Count > 0 && current.size13x19UpgradeVariantId) {
            cartItems.push({
              id: current.size13x19UpgradeVariantId,
              quantity: size13x19Count * packQty,
              properties: {
                "Upgrade For": current.title,
                "Upgrade Type": "13 × 19 Poster Size"
              }
            });
          }
        }
      }

      const res = await fetch(window.Shopify.routes.root + "cart/add.js", {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ items: cartItems })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.description || "Could not add customized item.");
      window.location.href = window.Shopify.routes.root + "cart";
    } catch(e) {
      alert(e.message); addCustom.disabled=false; addCustom.textContent="Upload & Add to Cart";
    }
  });
});