
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-postr-motion-wall]").forEach(section => {
    if (!window.matchMedia("(pointer:fine) and (prefers-reduced-motion:no-preference)").matches) return;

    section.querySelectorAll(".postr-motion-card").forEach(card => {
      card.addEventListener("mousemove", e => {
        const r = card.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width - .5;
        const y = (e.clientY - r.top) / r.height - .5;
        card.style.setProperty("--postr-tilt-x", `${y * -3}deg`);
        card.style.setProperty("--postr-tilt-y", `${x * 4}deg`);
      });
      card.addEventListener("mouseleave", () => {
        card.style.removeProperty("--postr-tilt-x");
        card.style.removeProperty("--postr-tilt-y");
      });
    });
  });
});
