
document.addEventListener("DOMContentLoaded", () => {
  const header = document.querySelector(".postr-premium-header");
  if (!header) return;

  requestAnimationFrame(() => {
    header.classList.add("postr-header-ready");
  });

  const updateScrollState = () => {
    header.classList.toggle("postr-is-scrolled", window.scrollY > 24);
  };

  updateScrollState();
  window.addEventListener("scroll", updateScrollState, { passive: true });

  /* Tiny magnetic movement on desktop navigation — intentionally subtle. */
  if (window.matchMedia("(min-width: 990px) and (prefers-reduced-motion: no-preference)").matches) {
    header.querySelectorAll(".header__menu-item").forEach((item) => {
      item.addEventListener("mousemove", (event) => {
        const box = item.getBoundingClientRect();
        const x = (event.clientX - box.left - box.width / 2) * 0.035;
        const y = (event.clientY - box.top - box.height / 2) * 0.06;
        item.style.transform = `translate(${x}px, ${y - 2}px)`;
      });

      item.addEventListener("mouseleave", () => {
        item.style.transform = "";
      });
    });
  }
});


// POSTR cart micro-animation whenever custom product logic dispatches postr:cart-added.
document.addEventListener("postr:cart-added", () => {
  const cart = document.querySelector(".postr-premium-header .header__icon--cart");
  if (!cart) return;

  cart.classList.remove("postr-cart-bounce");
  void cart.offsetWidth;
  cart.classList.add("postr-cart-bounce");

  window.setTimeout(() => {
    cart.classList.remove("postr-cart-bounce");
  }, 650);
});
