document.addEventListener("DOMContentLoaded", function () {

  const root = document.querySelector("[data-postr-studio]");
  if (!root) return;

  const endpoint = root.dataset.uploadEndpoint || "";

  let currentProduct = null;
  let posterFiles = [];
  let polaroidFiles = [];

  const tabs = root.querySelectorAll("[data-tab]");
  const cards = root.querySelectorAll("[data-product-category]");

  tabs.forEach(function (tab) {
    tab.addEventListener("click", function () {
      const selected = tab.dataset.tab;

      tabs.forEach(function (item) {
        item.classList.remove("is-active");
      });

      tab.classList.add("is-active");

      cards.forEach(function (card) {
        const category = card.dataset.productCategory;
        card.style.display =
          selected === "all" || selected === category
            ? ""
            : "none";
      });
    });
  });

  root.querySelectorAll(".postr-product-card").forEach(function (card) {
    const minus = card.querySelector("[data-card-minus]");
    const plus = card.querySelector("[data-card-plus]");
    const input = card.querySelector("[data-card-qty]");

    if (!input) return;

    minus.addEventListener("click", function () {
      input.value = Math.max(1, Number(input.value) - 1);
    });

    plus.addEventListener("click", function () {
      input.value = Number(input.value) + 1;
    });
  });

  root.querySelectorAll("[data-ready-add]").forEach(function (button) {
    button.addEventListener("click", async function () {

      const card = button.closest(".postr-product-card");
      const qty = card.querySelector("[data-card-qty]");

      button.disabled = true;
      button.textContent = "Adding...";

      try {
        const response = await fetch(
          window.Shopify.routes.root + "cart/add.js",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              items: [
                {
                  id: Number(button.dataset.variantId),
                  quantity: Math.max(1, Number(qty.value))
                }
              ]
            })
          }
        );

        if (!response.ok) {
          throw new Error("Could not add item.");
        }

        button.textContent = "Added ✓";

        setTimeout(function () {
          button.textContent = "Add to Cart";
          button.disabled = false;
        }, 1500);
      }

      catch (error) {
        alert(error.message);
        button.textContent = "Add to Cart";
        button.disabled = false;
      }
    });
  });

  const empty = root.querySelector("[data-customizer-empty]");
  const panel = root.querySelector("[data-customizer-panel]");
  const title = root.querySelector("[data-customizer-title]");

  const posterSection = root.querySelector("[data-poster-section]");
  const posterGrid = root.querySelector("[data-poster-grid]");

  const polaroidSection = root.querySelector("[data-polaroid-section]");
  const polaroidGrid = root.querySelector("[data-polaroid-grid]");

  const posterInstruction = root.querySelector("[data-poster-instruction]");
  const polaroidInstruction = root.querySelector("[data-polaroid-instruction]");

  const priceItem = root.querySelector("[data-price-per-item]");
  const priceTotal = root.querySelector("[data-price-total]");
  const qtyInput = root.querySelector("[data-custom-qty]");
  const lightsOption = root.querySelector("[data-lights-option]");

  function money(cents) {
    return "₹" + Math.round(Number(cents) / 100);
  }

  function createUploadTile(index, type) {

    const wrapper = document.createElement("label");
    wrapper.className = "postr-photo-slot";

    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/jpeg,image/png,image/webp";

    const placeholder = document.createElement("div");
    placeholder.className = "postr-photo-slot-placeholder";

    placeholder.innerHTML = `
      <span>+</span>
      <small>
        ${type === "poster" ? "Poster" : "Photo"} ${index + 1}
      </small>
    `;

    const preview = document.createElement("img");
    preview.hidden = true;

    input.addEventListener("change", function () {
      const file = input.files[0];
      if (!file) return;

      const url = URL.createObjectURL(file);

      preview.src = url;
      preview.hidden = false;
      placeholder.hidden = true;

      if (type === "poster") {
        posterFiles[index] = file;
      }
      else {
        polaroidFiles[index] = file;
      }
    });

    wrapper.appendChild(input);
    wrapper.appendChild(placeholder);
    wrapper.appendChild(preview);

    return wrapper;
  }

  function buildGrid(container, count, type) {
    container.innerHTML = "";

    for (let i = 0; i < count; i++) {
      container.appendChild(
        createUploadTile(i, type)
      );
    }
  }

  root.querySelectorAll("[data-open-customizer]").forEach(function (button) {
    button.addEventListener("click", function () {

      posterFiles = [];
      polaroidFiles = [];

      currentProduct = {
        title: button.dataset.title,
        variantId: Number(button.dataset.variantId),
        price: Number(button.dataset.price),
        posterCount: Number(button.dataset.posterCount),
        polaroidCount: Number(button.dataset.polaroidCount),
        lights: button.dataset.lights === "true"
      };

      title.textContent = currentProduct.title;

      priceItem.textContent =
        money(currentProduct.price);

      qtyInput.value = 1;

      updateTotal();

      if (currentProduct.posterCount > 0) {

        posterSection.hidden = false;

        posterInstruction.textContent =
          `Upload ${currentProduct.posterCount} poster photo(s).`;

        buildGrid(
          posterGrid,
          currentProduct.posterCount,
          "poster"
        );
      }

      else {
        posterSection.hidden = true;
      }

      if (currentProduct.polaroidCount > 0) {

        polaroidSection.hidden = false;

        polaroidInstruction.textContent =
          `Upload ${currentProduct.polaroidCount} Polaroid photo(s).`;

        buildGrid(
          polaroidGrid,
          currentProduct.polaroidCount,
          "polaroid"
        );
      }

      else {
        polaroidSection.hidden = true;
      }

      lightsOption.hidden =
        !currentProduct.lights;

      empty.hidden = true;
      panel.hidden = false;

      if (window.innerWidth < 1000) {
        panel.scrollIntoView({
          behavior: "smooth"
        });
      }
    });
  });

  root.querySelector("[data-custom-minus]")
    .addEventListener("click", function () {

      qtyInput.value =
        Math.max(
          1,
          Number(qtyInput.value) - 1
        );

      updateTotal();
    });

  root.querySelector("[data-custom-plus]")
    .addEventListener("click", function () {

      qtyInput.value =
        Number(qtyInput.value) + 1;

      updateTotal();
    });

  qtyInput.addEventListener(
    "input",
    updateTotal
  );

  function updateTotal() {

    if (!currentProduct) return;

    const q =
      Math.max(
        1,
        Number(qtyInput.value)
      );

    priceTotal.textContent =
      money(
        currentProduct.price * q
      );
  }

  root.querySelector("[data-customizer-close]")
    .addEventListener("click", function () {

      panel.hidden = true;
      empty.hidden = false;
      currentProduct = null;
    });

  async function uploadPhoto(file, type) {

    if (!endpoint) {
      throw new Error(
        "Cloudflare upload URL has not been configured yet."
      );
    }

    const form =
      new FormData();

    form.append(
      "file",
      file
    );

    form.append(
      "role",
      type
    );

    const response =
      await fetch(
        endpoint,
        {
          method: "POST",
          body: form
        }
      );

    const result =
      await response.json();

    if (!response.ok) {
      throw new Error(
        result.error ||
        "Upload failed."
      );
    }

    return (
      result.key ||
      result.url
    );
  }

  root.querySelector("[data-custom-add-cart]")
    .addEventListener("click", async function () {

      if (!currentProduct) return;

      if (
        posterFiles.filter(Boolean).length
        !== currentProduct.posterCount
      ) {
        alert(
          `Please upload all ${currentProduct.posterCount} poster photo(s).`
        );
        return;
      }

      if (
        polaroidFiles.filter(Boolean).length
        !== currentProduct.polaroidCount
      ) {
        alert(
          `Please upload all ${currentProduct.polaroidCount} Polaroid photo(s).`
        );
        return;
      }

      const button = this;

      button.disabled = true;
      button.textContent = "Uploading photos...";

      try {

        const posterRefs = [];

        for (const file of posterFiles) {
          if (file) {
            posterRefs.push(
              await uploadPhoto(
                file,
                "poster"
              )
            );
          }
        }

        const polaroidRefs = [];

        for (const file of polaroidFiles) {
          if (file) {
            polaroidRefs.push(
              await uploadPhoto(
                file,
                "polaroid"
              )
            );
          }
        }

        const selectedFrame =
          root.querySelector(
            'input[name="postr-frame"]:checked'
          ).value;

        const finish =
          root.querySelector(
            "[data-finish]"
          ).value;

        const note =
          root.querySelector(
            "[data-customer-note]"
          ).value;

        const lights =
          root.querySelector(
            "[data-lights]"
          );

        const properties = {

          "Customization":
            "Yes",

          "Frame":
            selectedFrame,

          "Finish":
            finish,

          "Poster Files":
            posterRefs.join(", "),

          "Polaroid Files":
            polaroidRefs.join(", ")

        };

        if (!lightsOption.hidden) {
          properties[
            "Fairy Lights"
          ] =
            lights.checked
            ? "Included"
            : "No";
        }

        if (note.trim()) {
          properties[
            "Customer Message"
          ] =
            note.trim();
        }

        button.textContent =
          "Adding to cart...";

        const response =
          await fetch(
            window.Shopify.routes.root +
            "cart/add.js",
            {
              method:
                "POST",

              headers: {
                "Content-Type":
                  "application/json"
              },

              body:
                JSON.stringify({
                  items: [
                    {
                      id:
                        currentProduct.variantId,

                      quantity:
                        Math.max(
                          1,
                          Number(
                            qtyInput.value
                          )
                        ),

                      properties:
                        properties
                    }
                  ]
                })
            }
          );

        const data =
          await response.json();

        if (!response.ok) {
          throw new Error(
            data.description ||
            "Could not add product."
          );
        }

        window.location.href =
          window.Shopify.routes.root +
          "cart";
      }

      catch (error) {

        alert(
          error.message
        );

        button.disabled =
          false;

        button.textContent =
          "Upload & Add to Cart";
      }
    });

});
