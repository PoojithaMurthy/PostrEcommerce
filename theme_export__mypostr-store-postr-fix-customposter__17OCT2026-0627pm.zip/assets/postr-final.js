/**
 * Postr. final UI helpers — visual only.
 * Does not touch cart/add, checkout, uploads, or variant logic.
 */
(function () {
  function markBuyPostersNav() {
    var links = document.querySelectorAll(
      ".header__menu-item, .menu-drawer__menu-item, .header__submenu .header__menu-item"
    );
    links.forEach(function (link) {
      var label = (link.textContent || "").replace(/\s+/g, " ").trim().toLowerCase();
      if (
        label === "buy posters" ||
        label.indexOf("buy posters") !== -1 ||
        label === "shop posters"
      ) {
        link.classList.add("postr-nav-cta");
      }
    });
  }

  function initReveals() {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      document.querySelectorAll(".postr-reveal-once").forEach(function (el) {
        el.classList.add("is-in");
      });
      return;
    }

    var targets = document.querySelectorAll(
      [
        ".postr-section-head",
        ".postr-edge-card",
        ".postr-category-deck__head",
        ".postr-category-deck__card",
        ".postr-4tab__head",
        ".postr-about-story",
        ".postr-about-community",
        ".postr-card:not(.postr-card--creative)",
        ".newsletter__wrapper",
      ].join(",")
    );

    targets.forEach(function (el) {
      if (el.closest("[data-postr-motion-wall], .postr-motion-wall, .postr-motion-track")) return;
      if (el.classList.contains("postr-reveal-once")) return;
      el.classList.add("postr-reveal-once");
    });

    var nodes = document.querySelectorAll(".postr-reveal-once");
    if (!("IntersectionObserver" in window) || !nodes.length) {
      nodes.forEach(function (el) {
        el.classList.add("is-in");
      });
      return;
    }

    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (!entry.isIntersecting) return;
          entry.target.classList.add("is-in");
          io.unobserve(entry.target);
        });
      },
      { threshold: 0.14, rootMargin: "0px 0px -40px 0px" }
    );

    nodes.forEach(function (el) {
      io.observe(el);
    });
  }

  function initDesignGallery() {
    if (document.querySelector("[data-postr-design-lightbox]")) return;

    var box = document.createElement("div");
    box.className = "postr-design-lightbox";
    box.hidden = true;
    box.setAttribute("data-postr-design-lightbox", "");
    box.innerHTML =
      '<button type="button" class="postr-design-lightbox__close" data-postr-design-close aria-label="Close">&times;</button>' +
      '<button type="button" class="postr-design-lightbox__nav postr-design-lightbox__nav--prev" data-postr-design-prev aria-label="Previous">‹</button>' +
      '<img class="postr-design-lightbox__img" data-postr-design-img alt="Design preview">' +
      '<button type="button" class="postr-design-lightbox__nav postr-design-lightbox__nav--next" data-postr-design-next aria-label="Next">›</button>' +
      '<p class="postr-design-lightbox__counter" data-postr-design-counter></p>';
    document.body.appendChild(box);

    var state = { images: [], index: 0 };
    var imgEl = box.querySelector("[data-postr-design-img]");
    var counterEl = box.querySelector("[data-postr-design-counter]");
    var prevBtn = box.querySelector("[data-postr-design-prev]");
    var nextBtn = box.querySelector("[data-postr-design-next]");

    function render() {
      if (!state.images.length) return;
      imgEl.src = state.images[state.index];
      imgEl.alt = "Design " + (state.index + 1) + " of " + state.images.length;
      counterEl.textContent =
        state.images.length > 1
          ? state.index + 1 + " / " + state.images.length
          : "";
      var multi = state.images.length > 1;
      prevBtn.hidden = !multi;
      nextBtn.hidden = !multi;
    }

    function open(images, start) {
      state.images = images.filter(Boolean);
      if (!state.images.length) return;
      state.index = Math.max(0, Math.min(start || 0, state.images.length - 1));
      box.hidden = false;
      document.body.style.overflow = "hidden";
      render();
    }

    function close() {
      box.hidden = true;
      document.body.style.overflow = "";
      imgEl.removeAttribute("src");
    }

    function step(delta) {
      if (state.images.length < 2) return;
      state.index = (state.index + delta + state.images.length) % state.images.length;
      render();
    }

    box.addEventListener("click", function (e) {
      if (e.target === box || e.target.closest("[data-postr-design-close]")) close();
    });
    prevBtn.addEventListener("click", function (e) {
      e.stopPropagation();
      step(-1);
    });
    nextBtn.addEventListener("click", function (e) {
      e.stopPropagation();
      step(1);
    });
    document.addEventListener("keydown", function (e) {
      if (box.hidden) return;
      if (e.key === "Escape") close();
      if (e.key === "ArrowLeft") step(-1);
      if (e.key === "ArrowRight") step(1);
    });

    var touchStartX = 0;
    box.addEventListener(
      "touchstart",
      function (e) {
        if (!e.changedTouches || !e.changedTouches.length) return;
        touchStartX = e.changedTouches[0].clientX;
      },
      { passive: true }
    );
    box.addEventListener(
      "touchend",
      function (e) {
        if (!e.changedTouches || !e.changedTouches.length) return;
        var dx = e.changedTouches[0].clientX - touchStartX;
        if (Math.abs(dx) < 40) return;
        if (dx > 0) step(-1);
        else step(1);
      },
      { passive: true }
    );

    document.addEventListener("click", function (e) {
      var btn = e.target.closest("[data-postr-design-open]");
      if (!btn) return;
      e.preventDefault();
      var targetId = btn.getAttribute("data-postr-design-target");
      var source = targetId ? document.getElementById(targetId) : null;
      if (!source) return;
      var images = Array.prototype.map
        .call(source.querySelectorAll("img"), function (node) {
          return node.getAttribute("src");
        })
        .filter(Boolean);
      open(images, 0);
    });
  }

  function boot() {
    markBuyPostersNav();
    initReveals();
    initDesignGallery();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }

  document.addEventListener("shopify:section:load", function () {
    markBuyPostersNav();
    initReveals();
  });
})();
