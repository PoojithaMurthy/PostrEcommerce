document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-postr-category-deck]").forEach(section => {
    if (!("IntersectionObserver" in window)) {
      section.classList.add("is-open");
      return;
    }

    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add("is-open");
        observer.unobserve(entry.target);
      });
    }, {
      threshold: 0.22,
      rootMargin: "0px 0px -5% 0px"
    });

    observer.observe(section);
  });

  document.addEventListener("shopify:section:load", event => {
    const section = event.target.querySelector?.("[data-postr-category-deck]");
    if (section) section.classList.add("is-open");
  });
});
