document.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll("[data-postr-products-studio]").forEach(function(root) {
    const endpoint = (root.dataset.uploadEndpoint || "").trim();
    let current = null, multiFiles = [], posterFiles = [], polaroidFiles = [], gridFile = null;
    let gridLayout = { name:"3x1", cols:3, rows:1 };

    const tabs = [...root.querySelectorAll("[data-tab]")];
    const cards = [...root.querySelectorAll("[data-category]")];
    tabs.forEach(tab => tab.addEventListener("click", () => {
      tabs.forEach(x => x.classList.remove("is-active"));
      tab.classList.add("is-active");
      const c = tab.dataset.tab;
      cards.forEach(card => card.hidden = c !== "all" && card.dataset.category !== c);
    }));

    root.querySelectorAll(".postr-ps-card").forEach(card => {
      const minus = card.querySelector("[data-ready-minus]"), plus = card.querySelector("[data-ready-plus]"), qty = card.querySelector("[data-ready-qty]");
      if (!qty) return;
      minus.addEventListener("click", () => qty.value = Math.max(1, Number(qty.value || 1) - 1));
      plus.addEventListener("click", () => qty.value = Math.max(1, Number(qty.value || 1) + 1));
    });

    root.querySelectorAll("[data-ready-add]").forEach(btn => btn.addEventListener("click", async () => {
      const card = btn.closest(".postr-ps-card");
      const qty = card.querySelector("[data-ready-qty]");
      btn.disabled = true; btn.textContent = "Adding...";
      try {
        const res = await fetch(window.Shopify.routes.root + "cart/add.js", {
          method:"POST",
          headers:{"Content-Type":"application/json","Accept":"application/json"},
          body:JSON.stringify({items:[{id:Number(btn.dataset.variantId),quantity:Math.max(1,Number(qty.value||1))}]})
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.description || "Could not add item.");
        btn.textContent = "Added ✓";
        setTimeout(()=>{btn.disabled=false;btn.textContent="Add to Cart";},1200);
      } catch(e) { alert(e.message); btn.disabled=false; btn.textContent="Add to Cart"; }
    }));

    const empty = root.querySelector("[data-empty-state]"), panel = root.querySelector("[data-customizer-panel]"), title = root.querySelector("[data-customizer-title]");
    const multiStep = root.querySelector("[data-multi-step]"), multiHelp = root.querySelector("[data-multi-help]"), multiGrid = root.querySelector("[data-multi-grid]");
    const posterStep = root.querySelector("[data-poster-step]"), posterHelp = root.querySelector("[data-poster-help]"), posterGrid = root.querySelector("[data-poster-grid]");
    const polaroidStep = root.querySelector("[data-polaroid-step]"), polaroidHelp = root.querySelector("[data-polaroid-help]"), polaroidGrid = root.querySelector("[data-polaroid-grid]");
    const gridBuilder = root.querySelector("[data-grid-builder]"), gridInput = root.querySelector("[data-grid-file]"), gridPreview = root.querySelector("[data-grid-preview]"), gridPreviewEmpty = root.querySelector("[data-grid-preview-empty]");
    const pieceCount = root.querySelector("[data-piece-count]"), gridButtons = [...root.querySelectorAll("[data-grid-layout]")];
    const lightsOption = root.querySelector("[data-lights-option]"), frameOption = root.querySelector("[data-frame-option]");
    const qty = root.querySelector("[data-custom-qty]"), itemPrice = root.querySelector("[data-price-item]"), totalPrice = root.querySelector("[data-price-total]");
    const note = root.querySelector("[data-note]"), finish = root.querySelector("[data-finish]"), addCustom = root.querySelector("[data-add-custom]");
    const money = cents => "₹" + Math.round(Number(cents||0)/100);

    function slot(index, role) {
      const label = document.createElement("label"); label.className="postr-ps-photo-slot";
      const input = document.createElement("input"); input.type="file"; input.accept="image/jpeg,image/png,image/webp";
      const ph = document.createElement("div"); ph.className="postr-ps-photo-placeholder"; ph.innerHTML=`<b>+</b><small>${role==="poster"?"Poster":"Photo"} ${index+1}</small>`;
      const img = document.createElement("img"); img.hidden=true;
      input.addEventListener("change",()=> {
        const f=input.files[0]; if(!f)return;
        if(f.size>10*1024*1024){alert("Maximum file size is 10MB.");input.value="";return;}
        img.src=URL.createObjectURL(f); img.hidden=false; ph.hidden=true;
        if(role==="multi")multiFiles[index]=f;
        if(role==="poster")posterFiles[index]=f;
        if(role==="polaroid")polaroidFiles[index]=f;
      });
      label.append(input,ph,img); return label;
    }

    function build(container,count,role){container.innerHTML="";for(let i=0;i<count;i++)container.appendChild(slot(i,role));}

    function renderGrid(){
      pieceCount.textContent=gridLayout.cols*gridLayout.rows;
      if(!gridFile)return;
      const src=URL.createObjectURL(gridFile);
      gridPreview.innerHTML="";
      gridPreview.style.gridTemplateColumns=`repeat(${gridLayout.cols},1fr)`;
      gridPreview.style.gridTemplateRows=`repeat(${gridLayout.rows},1fr)`;
      const total=gridLayout.cols*gridLayout.rows;
      for(let i=0;i<total;i++){
        const cell=document.createElement("div"); cell.className="postr-ps-grid-preview__cell";
        const img=document.createElement("img"); img.src=src;
        const col=i%gridLayout.cols,row=Math.floor(i/gridLayout.cols);
        img.style.width=`${gridLayout.cols*100}%`; img.style.height=`${gridLayout.rows*100}%`; img.style.maxWidth="none";
        img.style.transform=`translate(${-col*(100/gridLayout.cols)}%,${-row*(100/gridLayout.rows)}%)`; img.style.transformOrigin="top left";
        cell.appendChild(img); gridPreview.appendChild(cell);
      }
      gridPreviewEmpty.hidden=true;gridPreview.hidden=false;
    }

    gridButtons.forEach(btn=>btn.addEventListener("click",()=>{
      gridButtons.forEach(x=>x.classList.remove("is-active"));btn.classList.add("is-active");
      gridLayout={name:btn.dataset.gridLayout,cols:Number(btn.dataset.cols),rows:Number(btn.dataset.rows)};renderGrid();
    }));
    gridInput.addEventListener("change",()=>{const f=gridInput.files[0];if(!f)return;if(f.size>10*1024*1024){alert("Maximum file size is 10MB.");gridInput.value="";return;}gridFile=f;renderGrid();});

    function updatePrice(){if(!current)return;const q=Math.max(1,Number(qty.value||1));itemPrice.textContent=money(current.price);totalPrice.textContent=money(current.price*q);}
    root.querySelector("[data-custom-minus]").addEventListener("click",()=>{qty.value=Math.max(1,Number(qty.value||1)-1);updatePrice();});
    root.querySelector("[data-custom-plus]").addEventListener("click",()=>{qty.value=Math.max(1,Number(qty.value||1)+1);updatePrice();});
    qty.addEventListener("input",updatePrice);

    root.querySelectorAll("[data-open-customizer]").forEach(btn=>btn.addEventListener("click",()=>{
      multiFiles=[];posterFiles=[];polaroidFiles=[];gridFile=null;gridInput.value="";gridPreview.hidden=true;gridPreviewEmpty.hidden=false;
      current={mode:btn.dataset.mode,title:btn.dataset.title,variantId:Number(btn.dataset.variantId),price:Number(btn.dataset.price),photoCount:Number(btn.dataset.photoCount||0),posterCount:Number(btn.dataset.posterCount||0),polaroidCount:Number(btn.dataset.polaroidCount||0),lights:btn.dataset.lights==="true"};
      title.textContent=current.title;qty.value=1;note.value="";
      multiStep.hidden=true;posterStep.hidden=true;polaroidStep.hidden=true;gridBuilder.hidden=true;
      if(current.mode==="polaroid"){multiStep.hidden=false;multiHelp.textContent=`Upload exactly ${current.photoCount} photo(s).`;build(multiGrid,current.photoCount,"multi");}
      if(current.mode==="combo"){
        if(current.posterCount>0){posterStep.hidden=false;posterHelp.textContent=`Upload exactly ${current.posterCount} poster photo(s).`;build(posterGrid,current.posterCount,"poster");}
        if(current.polaroidCount>0){polaroidStep.hidden=false;polaroidHelp.textContent=`Upload exactly ${current.polaroidCount} Polaroid photo(s).`;build(polaroidGrid,current.polaroidCount,"polaroid");}
      }
      if(current.mode==="grid"){gridBuilder.hidden=false;frameOption.hidden=true;}else{frameOption.hidden=false;}
      lightsOption.hidden=!current.lights;empty.hidden=true;panel.hidden=false;updatePrice();
      if(window.innerWidth<1100)panel.scrollIntoView({behavior:"smooth",block:"start"});
    }));

    root.querySelector("[data-close-customizer]").addEventListener("click",()=>{current=null;panel.hidden=true;empty.hidden=false;});

    async function uploadFile(file,role){
      if(!endpoint)throw new Error("Cloudflare upload URL is not configured yet.");
      const form=new FormData();form.append("file",file);form.append("role",role);
      const res=await fetch(endpoint,{method:"POST",body:form});const data=await res.json();
      if(!res.ok)throw new Error(data.error||"Upload failed.");return data.key||data.url;
    }
    async function uploadMany(files,role){const refs=[];for(const f of files){if(f)refs.push(await uploadFile(f,role));}return refs;}

    addCustom.addEventListener("click",async()=>{
      if(!current)return;
      if(current.mode==="polaroid"&&multiFiles.filter(Boolean).length!==current.photoCount){alert(`Please upload all ${current.photoCount} photo(s).`);return;}
      if(current.mode==="combo"){
        if(posterFiles.filter(Boolean).length!==current.posterCount){alert(`Please upload all ${current.posterCount} poster photo(s).`);return;}
        if(polaroidFiles.filter(Boolean).length!==current.polaroidCount){alert(`Please upload all ${current.polaroidCount} Polaroid photo(s).`);return;}
      }
      if(current.mode==="grid"&&!gridFile){alert("Please upload an image for the photo grid.");return;}
      addCustom.disabled=true;addCustom.textContent="Uploading...";
      try{
        let multiRefs=[],posterRefs=[],polaroidRefs=[],gridRef="";
        if(current.mode==="polaroid")multiRefs=await uploadMany(multiFiles,"polaroid");
        if(current.mode==="combo"){posterRefs=await uploadMany(posterFiles,"poster");polaroidRefs=await uploadMany(polaroidFiles,"polaroid");}
        if(current.mode==="grid")gridRef=await uploadFile(gridFile,"grid");

        const frame=root.querySelector('input[name^="postr-ps-frame-"]:checked')?.value||"Classic White";
        const lights=root.querySelector("[data-lights-check]");
        const properties={"Customization":"Yes","Mode":current.mode,"Finish":finish.value,"Customer Note":note.value.trim()||"None"};
        if(current.mode!=="grid")properties["Frame / Style"]=frame;
        if(current.mode==="polaroid")properties["Photo Files"]=multiRefs.join(", ");
        if(current.mode==="combo"){properties["Poster Files"]=posterRefs.join(", ")||"None";properties["Polaroid Files"]=polaroidRefs.join(", ")||"None";}
        if(current.mode==="grid"){properties["Grid Image"]=gridRef;properties["Grid Layout"]=gridLayout.name;properties["Grid Pieces"]=String(gridLayout.cols*gridLayout.rows);}
        if(!lightsOption.hidden)properties["Fairy Lights"]=lights.checked?"Included":"No";

        addCustom.textContent="Adding to Cart...";
        const res=await fetch(window.Shopify.routes.root+"cart/add.js",{method:"POST",headers:{"Content-Type":"application/json","Accept":"application/json"},body:JSON.stringify({items:[{id:current.variantId,quantity:Math.max(1,Number(qty.value||1)),properties}]})});
        const data=await res.json();if(!res.ok)throw new Error(data.description||"Could not add customized item.");
        window.location.href=window.Shopify.routes.root+"cart";
      }catch(e){alert(e.message);addCustom.disabled=false;addCustom.textContent="Upload & Add to Cart";}
    });
  });
});
