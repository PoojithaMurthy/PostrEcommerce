document.addEventListener("DOMContentLoaded", function () {
  const header = document.querySelector(".header-wrapper");
  if (!header) return;

  function updateHeader() {
    header.classList.toggle("postr-scrolled", window.scrollY > 30);
  }

  updateHeader();
  window.addEventListener("scroll", updateHeader, { passive: true });
});
