document.addEventListener("DOMContentLoaded", () => {
  const reveals = document.querySelectorAll(".postr-reveal");

  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      });
    }, { threshold: 0.16, rootMargin: "0px 0px -6% 0px" });
    reveals.forEach(el => observer.observe(el));
  } else {
    reveals.forEach(el => el.classList.add("is-visible"));
  }

  document.querySelectorAll(".postr-edge-card").forEach(card => {
    card.addEventListener("click", event => {
      if (event.target.closest("a")) return;
      document.querySelectorAll(".postr-edge-card.is-popped").forEach(other => {
        if (other !== card) other.classList.remove("is-popped");
      });
      card.classList.toggle("is-popped");
    });
  });

  document.querySelectorAll("[data-postr-category-motion]").forEach(section => {
    if (!("IntersectionObserver" in window)) {
      section.classList.add("is-fanned");
      return;
    }
    const fanObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add("is-fanned");
        fanObserver.unobserve(entry.target);
      });
    }, { threshold: 0.22 });
    fanObserver.observe(section);
  });

  document.addEventListener("shopify:section:load", event => {
    event.target.querySelectorAll?.(".postr-reveal").forEach(el => el.classList.add("is-visible"));
    const category = event.target.querySelector?.("[data-postr-category-motion]");
    if (category) category.classList.add("is-fanned");
  });
});
